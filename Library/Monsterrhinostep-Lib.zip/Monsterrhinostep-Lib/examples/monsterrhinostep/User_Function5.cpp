#include "System.h"


uint32_t UserFunction5(uint32_t par, UserFunction* pUserFunction)
{
	return 1;
}