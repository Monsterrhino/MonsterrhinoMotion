#include "System.h"



void MotorInit(MotorClass* g_motor)
{
	g_motor->LoadMotorParameter();
	g_motor->SetMotorCurrent(50);
	g_motor->SetMotorCurrentHold(50);
	g_motor->Begin();
	g_motor->ResetRampStatus();
	g_motor->SetRampSpeeds(g_motor->GetStartup_RampSpeedsStart(), g_motor->GetStartup_RampSpeedsStop(), g_motor->GetStartup_RampSpeedsHold()); //Start, stop, threshold speeds
	g_motor->SetAccelerations(g_motor->GetStartup_AccelerationsAMax(), g_motor->GetStartup_AccelerationsDMax(), g_motor->GetStartup_AccelerationsA1(), g_motor->GetStartup_AccelerationsD1()); //AMAX, DMAX, A1, D1
	g_motor->SetMaxSpeed(300);

	return;
}

void MoveRelative(MotorClass* g_motor, uint64_t Event, uint32_t par, UserFunction* pUserFunction)
{
	Serial.print("MoveRelative Motor");
	Serial.print(par);
	Serial.println(" 300 steps!");
	g_motor->SetMoveRelative(1000);
	pUserFunction->m_MotorIoEvent.SetOrCondition(Event);
	if (pUserFunction->WaitEvent() == USERFUNCTIONEVENT_EXIT) return;
	return;
}

uint32_t UserFunction1(uint32_t par, UserFunction* pUserFunction)
{
	MotorInit(&g_Motor1);
	MotorInit(&g_Motor2);
	MotorInit(&g_Motor3);
	MotorInit(&g_Motor4);

	/*
	Input1: Motor 1 200 steps
	Input2: Motor 2 200 steps
	Input3: Motor 3 200 steps
	Input4: Motor 4 200 steps
	Input5: All motors 200 steps
	Userfunction 2 sub 0: M1 & M2 200 steps - wait - M3 & M4 200 steps
	*/

	switch (par) {
	case 1: MoveRelative(&g_Motor1, MOTORIOEVENT_MOTOR1PosReached, par, pUserFunction);
		break;
	case 2: MoveRelative(&g_Motor2, MOTORIOEVENT_MOTOR2PosReached, par, pUserFunction);
		break;
	case 3: MoveRelative(&g_Motor3, MOTORIOEVENT_MOTOR3PosReached, par, pUserFunction);
		break;
	case 4: MoveRelative(&g_Motor4, MOTORIOEVENT_MOTOR4PosReached, par, pUserFunction);
		break;
	case 5: MoveRelative(&g_Motor1, MOTORIOEVENT_MOTOR1PosReached, par, pUserFunction);
		MoveRelative(&g_Motor2, MOTORIOEVENT_MOTOR2PosReached, par, pUserFunction);
		MoveRelative(&g_Motor3, MOTORIOEVENT_MOTOR3PosReached, par, pUserFunction);
		MoveRelative(&g_Motor4, MOTORIOEVENT_MOTOR4PosReached, par, pUserFunction);
		break;
	default:
		MoveRelative(&g_Motor1, MOTORIOEVENT_MOTOR1PosReached, par, pUserFunction);
		MoveRelative(&g_Motor2, MOTORIOEVENT_MOTOR2PosReached, par, pUserFunction);
		vTaskDelay(100);
		MoveRelative(&g_Motor3, MOTORIOEVENT_MOTOR3PosReached, par, pUserFunction);
		MoveRelative(&g_Motor4, MOTORIOEVENT_MOTOR4PosReached, par, pUserFunction);
		break;
	}
	return 1;
}
