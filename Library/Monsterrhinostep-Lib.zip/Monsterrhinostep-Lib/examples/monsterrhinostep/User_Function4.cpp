
#include "System.h"



static void Init(UserFunction* pUserFunction)
{
	pUserFunction->Print_Info((char*)strStart);

	g_Motor1.LoadMotorParameter();
	g_Motor1.SetMotorCurrent(100);
	g_Motor1.SetMotorCurrentHold(50);
	g_Motor1.Begin();
	g_Motor1.ResetRampStatus();
	g_Motor1.SetRampSpeeds(g_Motor1.GetStartup_RampSpeedsStart(), g_Motor1.GetStartup_RampSpeedsStop(), g_Motor1.GetStartup_RampSpeedsHold()); //Start, stop, threshold speeds
	g_Motor1.SetAccelerations(g_Motor1.GetStartup_AccelerationsAMax(), g_Motor1.GetStartup_AccelerationsDMax(), g_Motor1.GetStartup_AccelerationsA1(), g_Motor1.GetStartup_AccelerationsD1()); //AMAX, DMAX, A1, D1

	g_Motor2.LoadMotorParameter();
	g_Motor2.SetMotorCurrent(100);
	g_Motor2.Begin();
	g_Motor2.ResetRampStatus();
	g_Motor2.SetRampSpeeds(g_Motor2.GetStartup_RampSpeedsStart(), g_Motor2.GetStartup_RampSpeedsStop(), g_Motor2.GetStartup_RampSpeedsHold()); //Start, stop, threshold speeds
	g_Motor2.SetAccelerations(g_Motor2.GetStartup_AccelerationsAMax(), g_Motor2.GetStartup_AccelerationsDMax(), g_Motor2.GetStartup_AccelerationsA1(), g_Motor2.GetStartup_AccelerationsD1()); //AMAX, DMAX, A1, D1

	g_Motor3.LoadMotorParameter();
	g_Motor3.SetMotorCurrent(100);
	g_Motor3.Begin();
	g_Motor3.ResetRampStatus();
	g_Motor3.SetRampSpeeds(g_Motor3.GetStartup_RampSpeedsStart(), g_Motor3.GetStartup_RampSpeedsStop(), g_Motor3.GetStartup_RampSpeedsHold()); //Start, stop, threshold speeds
	g_Motor3.SetAccelerations(g_Motor3.GetStartup_AccelerationsAMax(), g_Motor3.GetStartup_AccelerationsDMax(), g_Motor3.GetStartup_AccelerationsA1(), g_Motor3.GetStartup_AccelerationsD1()); //AMAX, DMAX, A1, D1

	g_Motor4.LoadMotorParameter();
	g_Motor4.SetMotorCurrent(100);
	g_Motor4.Begin();
	g_Motor4.ResetRampStatus();
	g_Motor4.SetRampSpeeds(g_Motor4.GetStartup_RampSpeedsStart(), g_Motor4.GetStartup_RampSpeedsStop(), g_Motor4.GetStartup_RampSpeedsHold()); //Start, stop, threshold speeds
	g_Motor4.SetAccelerations(g_Motor4.GetStartup_AccelerationsAMax(), g_Motor4.GetStartup_AccelerationsDMax(), g_Motor4.GetStartup_AccelerationsA1(), g_Motor4.GetStartup_AccelerationsD1()); //AMAX, DMAX, A1, D1


	g_Motor2.SetRampMode(MotorClass::RampMode::VELOCITY_MODE);
	g_Motor2.SetMaxSpeed(0);
	g_Motor1.SetRampMode(MotorClass::RampMode::VELOCITY_MODE);
	g_Motor1.SetMaxSpeed(0);

	bool toggle;

	return;

}


uint32_t RunMotors(UserFunction* pUserFunction) {

	g_Motor1.SetMaxSpeed(100);
	g_Motor2.SetMaxSpeed(50);

	g_Motor3.SetMaxSpeed(200);
	g_Motor4.SetMaxSpeed(200);

	while (1) {

		g_Motor1.SetMaxSpeed(100);
		g_Motor2.SetMaxSpeed(50);

		g_Motor3.SetTargetPosition(1000);
		//if (pUserFunction->SetTargetPosition_MotorWait(g_Motor3, 10000) == USERFUNCTIONEVENT_EXIT) return false;
		if (pUserFunction->SetTargetPosition_MotorWait(g_Motor4, -1000) == USERFUNCTIONEVENT_EXIT) return false;

		Serial.println("Change direction");
		g_Motor1.SetMaxSpeed(-20);
		g_Motor2.SetMaxSpeed(-150);


		g_Motor3.SetTargetPosition(0);
		if (pUserFunction->SetTargetPosition_MotorWait(g_Motor4, 0) == USERFUNCTIONEVENT_EXIT) return false;
	}
	return 1;
}

uint32_t UserFunction4(uint32_t par, UserFunction* pUserFunction)
{	
	Init(pUserFunction);

	if (par == 1) RunMotors(pUserFunction);
	return 1;
}
