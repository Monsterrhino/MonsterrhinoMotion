#include "System.h"


uint32_t UserFunction2(uint32_t par, UserFunction *pUserFunction)
{
	return 1;
}
