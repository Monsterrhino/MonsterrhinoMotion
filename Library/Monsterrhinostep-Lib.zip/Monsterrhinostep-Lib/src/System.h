// System.h

#ifndef _SYSTEM_h
#define _SYSTEM_h

/*
to do
	CommandUsb_System.cpp OK
	CommandUsb_MotorStartup 


*/


#if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif

#include <STM32FreeRTOS.h>

#include "CanMessage.h"
#include "Can.h"
#include "CCmdDecode.h"
#include "CommandUsb.h"
#include "EEprom.h"
#include "Input.h"
#include "Motor.h"
#include "MotorIoEvent.h"
#include "User_Function.h"
#include "ResourceLock.h"
#include "PortIni.h"


#define PWM_N 3

typedef void(*Function_t)();

#define DOOR_CTRL_SIG (0x01<<0)
#define DOOR_STATUS (0x01<<1)
#define DOOR_LATCH_STATUS (0x01<<2)


#define DEBUG_ALL 0x7f
#define DEBUG_INIT (1<<0)
#define DEBUG_DRIVERINIT (1<<1)
#define DEBUG_USBCOMMAND (1<<2)
#define DEBUG_ERROR (1<<3)
#define DEBUG_HOMING (1<<4)
#define DEBUG_MOTOR (1<<5)
#define DEBUG_STARTDELAY (1<<7)

class CSystem 
{
	friend class CanMessageClass;
 protected:
	  uint16_t m_HardwareVersion = 0;
	  uint8_t m_BordId = 0;
	  uint16_t m_MyAddress = 2;
	  uint8_t m_PWMvalue[3];
	  uint32_t m_PWMFrequency = 1000;
 public:
	 uint8_t m_PwmLookUserTask[3] = { 0,0,0 };
	 uint8_t m_PwmLookUserTaskSub[3] = { 0,0,0 };
	 uint16_t m_Debug = DEBUG_ALL;
	 void Init(Function_t func);
	static uint8_t GetTunePowerStage();
	static  void SetTunePowerStage(uint8_t mode);
	uint8_t GetStartUpDebugMode();
	void SetStartUpDebugMode(uint8_t value);
	uint8_t SetStartUpCanAdd(uint8_t value);
	int8_t GetStartUpCanAdd( );
	uint16_t GetStartUpCanVal();
	uint8_t SetCanAdd(uint8_t value);
	uint16_t GetCanAdd();
	uint8_t GetStartProgrammKey(uint8_t *key);
	int8_t SetStartProgrammKey(uint8_t *key);
	
	uint16_t GetHardwareVersion() { return m_HardwareVersion+1; };
	
	uint8_t GetBordId() { return m_BordId; };
	uint8_t SetStartUpCanSpeed(uint32_t value);
	uint32_t GetStartUpCanSpeed();
	uint8_t GetStartUpCanSpeedVal();
	uint8_t SetCanSpeed(uint32_t value);
	uint32_t GetCanSpeed();
	uint8_t GetDoor();
	void SetDoor(uint8_t value);
	void SetPWM(uint8_t channel, uint8_t value);
	uint8_t GetPWM(uint8_t channel);
	void SetPWMFrequency(uint32_t value);
	uint32_t GetPWMFrequency() { return m_PWMFrequency; };
	uint8_t SetStartUpPWM_Value(uint8_t channel, uint8_t value);
	uint8_t GetStartUpPWM_Value(uint8_t channel);
	void SetStartUpPWM_Frequency( uint32_t value);
	uint32_t GetStartUpPWM_Frequency();
};

extern CSystem g_System;

#endif

