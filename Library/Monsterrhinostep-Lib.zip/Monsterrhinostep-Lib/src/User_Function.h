// UserFunction.h

#ifndef _USERFUNCTION_h
#define _USERFUNCTION_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif
#include "Motor.h"
#include  "PortIni.h"
#include "MotorIoEvent.h"

#define n_USER_FUNCTION 6
#define n_USER_VARIABLE 6
#define n_USER_VARIABLE_FLOAT 4




#define USERFUNKTION_STATUS_START 1
#define USERFUNKTION_STATUS_WAIT 2
#define USERFUNKTION_STATUS_RUN 3
#define USERFUNKTION_STATUS_STOP 4


#define SET_USERFUNKTION_STATUS_START(nr) g_UserFunction[nr-1].m_Status=eTaskState::eReady;
#define SET_USERFUNKTION_STATUS_WAIT(nr) g_UserFunction[nr-1].m_Status=eTaskState::eBlocked;
#define SET_USERFUNKTION_STATUS_RUN(nr) g_UserFunction[nr-1].m_Status=eTaskState::eRunning;
#define SET_USERFUNKTION_STATUS_STOP(nr) g_UserFunction[nr-1].m_Status=eTaskState::eSuspended;
#define USERFUNKTION_STOP(nr) if ( g_UserFunction[nr-1].m_Status==eTaskState::eSuspended) 
#define USERFUNKTION_STOP_EXIT(nr) if ( g_UserFunction[nr-1].m_Status==eTaskState::eSuspended) break;











class UserFunction
{
protected:
	
	
	uint8_t m_RemoteCommand_Get_Data[8];
	uint8_t m_RemoteCommand_Get_DataLen = 0;
	uint8_t m_RemoteCommand_GetError = CANMESSAGE_ERROR_NONE;
	void Print_exit();
	uint8_t m_toAdd = 0;
	uint32_t RemoteCommand_GetSet(uint8_t toAdd, uint8_t get, uint8_t command, uint8_t nr, uint8_t subCommand, uint8_t* data, uint8_t len, uint32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0);
public:
	ResourceLockClass m_Lock;
	
	uint32_t m_variable[n_USER_VARIABLE];
	double m_variableFloat[n_USER_VARIABLE_FLOAT];
	
	uint8_t m_sub =0 ;
	uint8_t m_Nr = 0;
	eTaskState m_Status= eTaskState::eInvalid;
	static uint8_t Init();
	
	TaskHandle_t pxCreatedTask;
	MotorIoEventClass m_MotorIoEvent;
	/*
	static void NewEventMotor_PosReached(uint8_t nr);
	static void NewEventMotor_StopLeft(uint8_t nr);
	static void NewEventMotor_StopRight(uint8_t nr);
	static void NewEventMotor_StopStallGuard(uint8_t nr);
	static void NewEventSensorNO(uint8_t nr, uint8_t falling);
	static void NewEventSensorNC(uint8_t nr, uint8_t falling);
	static void NewEventLaser(uint8_t nr, uint8_t falling);
	*/
	uint32_t GetStartUp_Variable(uint8_t varNr);
	void SetStartUp_Variable(uint8_t varNr, uint32_t value);
	float GetStartUp_VariableFloat(uint8_t varNr);
	void SetStartUp_VariableFloat(uint8_t varNr, float value);
	uint32_t GetStartUp_Autostart();
	void SetStartUp_Autostart(uint32_t value);
	void EEpromInitDefault(uint8_t mode);
	void LoadVariable();
	uint32_t WaitEvent(uint32_t timeout = portMAX_DELAY);
	
	int8_t IsLock(uint32_t resurce);
	int8_t Lock_Wait(uint32_t resurce, uint32_t timeout = portMAX_DELAY);
	int8_t Lock(uint32_t resurce, uint32_t timeout = portMAX_DELAY);
	int8_t MotorHomingOk(uint32_t resurce, uint8_t sub, uint32_t timeout = portMAX_DELAY);
	void Unlock();
	
	void TiggerStart(uint32_t sub);
	void TiggerStop();
	static void Autostart();
	void Print_Info(char * str);
	uint32_t SetTargetPosition_MotorWait(MotorClass &motor, double pos);
	uint8_t RemoteCommand_Run(uint8_t add, uint8_t *data, uint8_t datalen, uint8_t  *error= NULL);
	
	
	uint32_t RemoteCommand_SetInt8(uint8_t toAdd,  uint8_t command, uint8_t nr, uint8_t subCommand, uint8_t value, uint32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0);
	uint32_t RemoteCommand_SetInt16(uint8_t toAdd,  uint8_t command, uint8_t nr, uint8_t subCommand, uint16_t value, uint32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0);
	uint32_t RemoteCommand_SetInt32(uint8_t toAdd,  uint8_t command, uint8_t nr, uint8_t subCommand, uint32_t value, uint32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0);
	uint32_t RemoteCommand_SetInt48(uint8_t toAdd,  uint8_t command, uint8_t nr, uint8_t subCommand, int64_t value, uint32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0);
	uint32_t RemoteCommand_RequestValue(uint8_t toAdd, uint8_t command, uint8_t nr, uint8_t subCommand, uint32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0);
	uint8_t RemoteCommand_GetError();
	int64_t RemoteCommand_GetRetValue_Int48();
	double RemoteCommand_GetRetValue_Double();

	inline uint32_t RemoteCommand_Motor_SetEmergencyStop(uint8_t toAdd, uint8_t nr,  int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::emergencyStop, 0, timeout, enableTriggerEvent);
	}

	inline uint32_t RemoteCommand_Motor_SetMotorStop(uint8_t toAdd, uint8_t nr, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::stop, 0, timeout, enableTriggerEvent);
	}

	inline uint32_t RemoteCommand_Motor_SetMotorEnable(uint8_t toAdd, uint8_t nr, uint8_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::enable, value, timeout, enableTriggerEvent);
	}

	inline uint32_t RemoteCommand_Motor_GetMotorEnable(uint8_t toAdd, uint8_t nr, uint8_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::enable, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetRampMode(uint8_t toAdd, uint8_t nr, uint8_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampMode, value, timeout, enableTriggerEvent);
	}

	inline uint32_t RemoteCommand_Motor_GetRampMode(uint8_t toAdd, uint8_t nr, uint8_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampMode, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetTargetPosition(uint8_t toAdd, uint8_t nr, double value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt48(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::targetPosition, value*1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetTargetPosition(uint8_t toAdd, uint8_t nr, double &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::targetPosition, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetMoveRelative(uint8_t toAdd, uint8_t nr, double value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt48(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::moveRelative, value * 1000, timeout, enableTriggerEvent);
	}
	

	inline uint32_t RemoteCommand_Motor_SetCurrentPosition(uint8_t toAdd, uint8_t nr, double value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt48(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::currentPosition, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetCurrentPosition(uint8_t toAdd, uint8_t nr, double &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::currentPosition, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetRampMaxSpeed(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampMaxSpeed, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetRampMaxSpeed(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampMaxSpeed, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetRampSpeedStart(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampSpeedStart, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetRampSpeedStart(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampSpeedStart, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetRampSpeedStop(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampSpeedStop, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetRampSpeedStop(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampSpeedStop, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetRampSpeedHold(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampSpeedHold, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetRampSpeedHold(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::rampSpeedHold, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_GetGetCurrentSpeed(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::getCurrentSpeed, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetAccelerationAMAX(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationAMAX, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetAccelerationAMAX(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationAMAX, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetAccelerationDMAX(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationDMAX, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetAccelerationDMAX(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationDMAX, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetAccelerationA1(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationA1, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetAccelerationA1(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationA1, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetAccelerationD1(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationD1, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetAccelerationD1(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::accelerationD1, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetPwmThrsSpeed(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::modeChangeSpeeds_pwmThrs, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetPwmThrsSpeed(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::modeChangeSpeeds_pwmThrs, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetCoolThrsSpeed(uint8_t toAdd, uint8_t nr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::modeChangeSpeeds_coolThrs, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetCoolThrsSpeed(uint8_t toAdd, uint8_t nr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::modeChangeSpeeds_coolThrs, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetCoolHighThrs(uint8_t toAdd, uint8_t nr, double value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::modeChangeSpeeds_highThrs, value * 1000, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetCoolHighThrs(uint8_t toAdd, uint8_t nr, double &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::modeChangeSpeeds_highThrs, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	
	inline uint32_t RemoteCommand_Motor_GetEncoderPosition(uint8_t toAdd, uint8_t nr, double &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::encoderPosition, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	
	inline uint32_t RemoteCommand_Motor_GetLatchedPosition(uint8_t toAdd, uint8_t nr, double &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::latchedPosition, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	
	inline uint32_t RemoteCommand_Motor_GetLatchedEncoderPosition(uint8_t toAdd, uint8_t nr, double &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::latchedEncoderPosition, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetSW_Mode(uint8_t toAdd, uint8_t nr, uint32_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::SW_Mode, value , timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetSW_Mode(uint8_t toAdd, uint8_t nr, uint32_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::SW_Mode, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	
	inline uint32_t RemoteCommand_Motor_Get_DRV_STATUS(uint8_t toAdd, uint8_t nr, uint32_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::DRV_STATUS, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_GetGstat(uint8_t toAdd, uint8_t nr, uint32_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::Gstat, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}
	inline uint32_t RemoteCommand_Motor_ResetGstat(uint8_t toAdd, uint8_t nr, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::Gstat, timeout, enableTriggerEvent);
	}

	inline uint32_t RemoteCommand_Motor_ResetRampStatus(uint8_t toAdd, uint8_t nr, uint32_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::RampStatus, value, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetRampStatus(uint8_t toAdd, uint8_t nr, uint32_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::RampStatus, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetCurrent(uint8_t toAdd, uint8_t nr, uint16_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt16(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::motorCurrent, value, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetCurrent(uint8_t toAdd, uint8_t nr, uint16_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::motorCurrent, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetCurrentReduction(uint8_t toAdd, uint8_t nr, uint16_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt16(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::motorCurrentReduction, value, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetCurrentReduction(uint8_t toAdd, uint8_t nr, uint16_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::motorCurrentReduction, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetFreewheeling(uint8_t toAdd, uint8_t nr, uint8_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::motorFreewheeling, value, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetFreewheeling(uint8_t toAdd, uint8_t nr, uint8_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::motorFreewheeling, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_Motor_SetIholddelay(uint8_t toAdd, uint8_t nr, uint8_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::iholddelay, value, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_Motor_GetIholddelay(uint8_t toAdd, uint8_t nr, uint8_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_MOTOR, nr, CanMessageClass::iholddelay, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}


	// User Function
	inline uint32_t RemoteCommand_UserFunction_SetStart(uint8_t toAdd, uint8_t nr, uint8_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_USER_FUNCTION, nr, CanMessageClass::userFunctionStart, value, timeout, enableTriggerEvent);
	}
	inline uint32_t RemoteCommand_UserFunction_GetStart(uint8_t toAdd, uint8_t nr, uint8_t &value,  int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_USER_FUNCTION, nr, CanMessageClass::userFunctionStart, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_UserFunction_SetVariable(uint8_t toAdd, uint8_t nr, uint8_t varNr, uint32_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		/*if (varNr > n_USER_VARIABLE) {
			m_RemoteCommand_GetError= CANMESSAGE_ERROR_OUT_OF_RANGE;
			return USERFUNCTIONEVENT_REMOTECOMMAND_ERR;
		}*/
		return RemoteCommand_SetInt32(toAdd, CANMESSAGE_COMMAND_USER_FUNCTION, nr, CanMessageClass::userFunctionVariable1 + varNr-1, value, timeout, enableTriggerEvent);
	}

	inline uint32_t RemoteCommand_UserFunction_GetVariable(uint8_t toAdd, uint8_t nr, uint8_t varNr, uint32_t &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		/*if (varNr > n_USER_VARIABLE) {
			m_RemoteCommand_GetError = CANMESSAGE_ERROR_OUT_OF_RANGE;
			return USERFUNCTIONEVENT_REMOTECOMMAND_ERR;
		}*/
		uint8_t ret= RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_USER_FUNCTION, nr, CanMessageClass::userFunctionVariable1 + varNr - 1, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value=RemoteCommand_GetRetValue_Int48();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_UserFunction_SetVariableFloat(uint8_t toAdd, uint8_t nr, uint8_t varNr, float value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		if (varNr > n_USER_VARIABLE_FLOAT) {
			m_RemoteCommand_GetError = CANMESSAGE_ERROR_OUT_OF_RANGE;
			return USERFUNCTIONEVENT_REMOTECOMMAND_ERR;
		}
		return RemoteCommand_SetInt48(toAdd, CANMESSAGE_COMMAND_USER_FUNCTION, nr, CanMessageClass::userFunctionVariable1_float + varNr - 1, value*1000, timeout, enableTriggerEvent);
	}


	inline uint32_t RemoteCommand_UserFunction_GetVariableFloat(uint8_t toAdd, uint8_t nr, uint8_t varNr, float &value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		if (varNr > n_USER_VARIABLE_FLOAT) {
			m_RemoteCommand_GetError = CANMESSAGE_ERROR_OUT_OF_RANGE;
			return USERFUNCTIONEVENT_REMOTECOMMAND_ERR;
		}
		uint8_t ret = RemoteCommand_RequestValue(toAdd, CANMESSAGE_COMMAND_USER_FUNCTION, nr, CanMessageClass::userFunctionVariable1_float + varNr - 1, timeout, enableTriggerEvent);
		if (ret == USERFUNCTIONEVENT_REMOTECOMMAND)
		{
			value = RemoteCommand_GetRetValue_Double();
		}
		return ret;
	}

	inline uint32_t RemoteCommand_UserFunction_UnLock(uint8_t toAdd, uint8_t nr, uint8_t value, int32_t timeout = portMAX_DELAY, uint8_t enableTriggerEvent = 0)
	{
		return RemoteCommand_SetInt8(toAdd, CANMESSAGE_COMMAND_USER_FUNCTION, nr, CanMessageClass::userFunctionUnLock, value, timeout, enableTriggerEvent);
	}
	

	
};


uint32_t UserFunction1(uint32_t par, UserFunction *pUserFunction);
uint32_t UserFunction2(uint32_t par, UserFunction *pUserFunction);
uint32_t UserFunction3(uint32_t par, UserFunction *pUserFunction);
uint32_t UserFunction4(uint32_t par, UserFunction *pUserFunction);
uint32_t UserFunction5(uint32_t par, UserFunction *pUserFunction);
uint32_t UserFunction6(uint32_t par, UserFunction *pUserFunction);

extern UserFunction g_UserFunction[n_USER_FUNCTION];

#endif

