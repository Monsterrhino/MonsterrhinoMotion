// MotorIoEvent.h

#ifndef _MOTORIOEVENT_h
#define _MOTORIOEVENT_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif



#include <STM32FreeRTOS.h>




#define USERFUNCTIONEVENT_TRIGGER 1
#define USERFUNCTIONEVENT_EXIT 2
#define USERFUNCTIONEVENT_REMOTECOMMAND 4
#define USERFUNCTIONEVENT_REMOTECOMMAND_ERR 8

#define MOTORIOEVENT_TRIGGERBIT_MOTOR1 (1<<0)
#define MOTORIOEVENT_TRIGGERBIT_MOTOR2 (1<<1)
#define MOTORIOEVENT_TRIGGERBIT_MOTOR3 (1<<2)
#define MOTORIOEVENT_TRIGGERBIT_MOTOR4 (1<<3)
#define MOTORIOEVENT_TRIGGERBIT_INPUT1_F (1<<4)
#define MOTORIOEVENT_TRIGGERBIT_INPUT1_R (1<<5)
#define MOTORIOEVENT_TRIGGERBIT_INPUT2_F (1<<6)
#define MOTORIOEVENT_TRIGGERBIT_INPUT2_R (1<<7)
#define MOTORIOEVENT_TRIGGERBIT_INPUT3_F (1<<8)
#define MOTORIOEVENT_TRIGGERBIT_INPUT3_R (1<<9)
#define MOTORIOEVENT_TRIGGERBIT_INPUT4_F (1<<10)
#define MOTORIOEVENT_TRIGGERBIT_INPUT4_R (1<<11)
#define MOTORIOEVENT_TRIGGERBIT_INPUT5_F (1<<12)
#define MOTORIOEVENT_TRIGGERBIT_INPUT5_R (1<<13)
#define MOTORIOEVENT_TRIGGERBIT_INPUT6_F (1<<14)
#define MOTORIOEVENT_TRIGGERBIT_INPUT6_R (1<<15)
#define MOTORIOEVENT_TRIGGERBIT_INPUT7_F (1<<16)
#define MOTORIOEVENT_TRIGGERBIT_INPUT7_R (1<<17)
#define MOTORIOEVENT_TRIGGERBIT_INPUT8_F (1<<18)
#define MOTORIOEVENT_TRIGGERBIT_INPUT8_R (1<<19)




#define MOTORIOEVENT_MOTOR1PosReached		(((uint64_t)1)<<0)	// motor 1 position reached
#define MOTORIOEVENT_MOTOR1StallGuard		(((uint64_t)1)<<1)	// motor 1 Stall Guard
#define MOTORIOEVENT_MOTOR1StopLeft			(((uint64_t)1)<<2)	// motor 1 stop left 
#define MOTORIOEVENT_MOTOR1StopRigth		(((uint64_t)1)<<3)	// motor 1 stop rigth 
#define MOTORIOEVENT_MOTOR2PosReached		(((uint64_t)1)<<4)	// motor 2 position reached
#define MOTORIOEVENT_MOTOR2StallGuard		(((uint64_t)1)<<5)	// motor 2 Stall Guard
#define MOTORIOEVENT_MOTOR2StopLeft			(((uint64_t)1)<<6)	// motor 2 stop left 
#define MOTORIOEVENT_MOTOR2StopRigth		(((uint64_t)1)<<7)	// motor 2 stop rigth
#define MOTORIOEVENT_MOTOR3PosReached		(((uint64_t)1)<<8)	// motor 3 position reached
#define MOTORIOEVENT_MOTOR3StallGuard		(((uint64_t)1)<<9)	// motor 3 Stall Guard
#define MOTORIOEVENT_MOTOR3StopLeft			(((uint64_t)1)<<10)	// motor 3 stop left 
#define MOTORIOEVENT_MOTOR3StopRigth		(((uint64_t)1)<<11)	// motor 3 stop rigth
#define MOTORIOEVENT_MOTOR4PosReached		(((uint64_t)1)<<12)	// motor 4 position reached
#define MOTORIOEVENT_MOTOR4StallGuard		(((uint64_t)1)<<13)	// motor 4 Stall Guard
#define MOTORIOEVENT_MOTOR4StopLeft			(((uint64_t)1)<<14)	// motor 4 stop left 
#define MOTORIOEVENT_MOTOR4StopRigth		(((uint64_t)1)<<15)	// motor 4 stop rigth

#define MOTORIOEVENT_INPUT1_FallingLow		(((uint64_t)1)<<16) // sensor 1 NO falling/low
#define MOTORIOEVENT_INPUT1_RisingHigh		(((uint64_t)1)<<17)	// sensor 1 NO RISING/HIGH
#define MOTORIOEVENT_INPUT1_Mode			(((uint64_t)1)<<18)	// sensor 1 NO RISING/PEGEL(only and)
#define MOTORIOEVENT_INPUT2_FallingLow		(((uint64_t)1)<<19) // sensor 1 NC falling/low
#define MOTORIOEVENT_INPUT2_RisingHigh		(((uint64_t)1)<<20)	// sensor 1 NC RISING/HIGH
#define MOTORIOEVENT_INPUT2_Mode			(((uint64_t)1)<<21)	// sensor 1 NC RISING/PEGEL(only and)

#define MOTORIOEVENT_INPUT3_FallingLow		(((uint64_t)1)<<22) // sensor 2 NO falling/low
#define MOTORIOEVENT_INPUT3_RisingHigh		(((uint64_t)1)<<23)	// sensor 2 NO RISING/HIGH
#define MOTORIOEVENT_INPUT3_Mode			(((uint64_t)1)<<24)	// sensor 2 NO RISING/PEGEL(only and)
#define MOTORIOEVENT_INPUT4_FallingLow		(((uint64_t)1)<<25) // sensor 2 NC falling/low
#define MOTORIOEVENT_INPUT4_RisingHigh		(((uint64_t)1)<<26)	// sensor 2 NC RISING/HIGH
#define MOTORIOEVENT_INPUT4_Mode			(((uint64_t)1)<<27)	// sensor 2 NC RISING/PEGEL(only and)

#define MOTORIOEVENT_INPUT5_FallingLow		(((uint64_t)1)<<28) // sensor 2 NO falling/low
#define MOTORIOEVENT_INPUT5_RisingHigh		(((uint64_t)1)<<29)	// sensor 2 NO RISING/HIGH
#define MOTORIOEVENT_INPUT5_Mode			(((uint64_t)1)<<30)	// sensor 2 NO RISING/PEGEL(only and)
#define MOTORIOEVENT_INPUT6_FallingLow		(((uint64_t)1)<<31) // sensor 2 NC falling/low
#define MOTORIOEVENT_INPUT6_RisingHigh		(((uint64_t)1)<<32)	// sensor 2 NC RISING/HIGH
#define MOTORIOEVENT_INPUT6_Mode			(((uint64_t)1)<<33)	// sensor 2 NC RISING/PEGEL(only and)

#define MOTORIOEVENT_INPUT7_FallingLow		(((uint64_t)1)<<34)	// laser 1 falling/low
#define MOTORIOEVENT_INPUT7_RisingHigh		(((uint64_t)1)<<35)	// laser 1 RISING/HIGH
#define MOTORIOEVENT_INPUT7_Mode			(((uint64_t)1)<<36)	// laser 1 RISING/PEGEL(only and)

#define MOTORIOEVENT_INPUT8_FallingLow		(((uint64_t)1)<<37)	// laser 1 falling/low
#define MOTORIOEVENT_INPUT8_RisingHigh		(((uint64_t)1)<<38)	// laser 1 RISING/HIGH
#define MOTORIOEVENT_INPUT8_Mode			(((uint64_t)1)<<39)	// laser 1 RISING/PEGEL(only and)


class MotorIoEventClass
{
public:
	
protected:
	uint64_t m_event = 0;
	uint64_t m_eventRegOr =  0 ;
	uint64_t m_eventRegAnd =  0 ;
	uint64_t m_eventMem =  0 ;
	
	


	
 public:
	 
	// SemaphoreHandle_t m_Event;
	 EventGroupHandle_t m_EventGroup;
	
	 uint8_t Init();
	uint8_t NewEvent(uint64_t trigger);
	void SetOrCondition(uint64_t even) ;
	void SetAndCondition(uint64_t even) ;
	static uint8_t NewEvent(uint32_t triggerBit);
	static uint8_t IsEventTaskInit();
	uint64_t GetEvent() { return m_event; };
	/*static void NewEventMotor_PosReached(uint8_t nr);
	static void NewEventMotor_StopLeft(uint8_t nr);
	static void NewEventMotor_StopRight(uint8_t nr);
	static void NewEventMotor_StopStallGuard(uint8_t nr);
	static void NewEventSensorNO(uint8_t nr, uint8_t falling);
	static void NewEventSensorNC(uint8_t nr, uint8_t falling);
	static void NewEventLaser(uint8_t nr, uint8_t falling);
	
	static void InitAll();*/
};


extern TaskHandle_t g_EventTask;
//extern MotorIoEventClass g_MotorIoEvent[N_MOTORIOEVENT];

#endif

