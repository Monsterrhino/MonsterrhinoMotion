/*
  debug - Library .
  Created by E. Kaserer, 26.02.2014.
  Released into the public domain.
*/
#ifndef CCMDDECODE_h
#define CCMDDECODE_h

#include "Arduino.h"

#define NUL   0  // NULL
#define BEL   7  // Bell
#define BS    8  // Backspace
#define HT    9  // Horizontal tab
#define LF    10 // Line feed
#define VT    11 // Vertical tab
#define FF    12 // Form feed
#define CR    13 // Carriage return
#define DEL   0x7f // Delete key for some terminals.

/*
-primery commands:
	motor(M)	<1-4>
	PWM(P)		<1-3,R,G,B>
	input(I)	<1-3 NC/NO>
	laser(L)	<>
	door(D)		
	stop(S)
	system(Y)

-desciption commands:
	-Motor(M) <1-4>; Motor 1-4 0=All
		-stop(S)			;Stop Motor
		-emergency stop(ES)	;Emergency stop
		-mode(M)<Positioning(P),Velocity(V),Hold(H)> Ramp mode selection :
			- Positioning mode : autonomous move to XTARGET using all A, D and V parameters.
			- Velocity mode : follows VMAX and AMAX. Call setMaxSpeed() AFTER switching to velocity mode.
			- Hold mode : Keep current velocity until a stop event occurs.
		-targetpos(TP);<int,?>
			 ; ? get target position in float (stepp)
			 : ?x get target position in hex (microstepp)
			 ; int set target position in float (stepp)
				exampes: motor 1 targetpos -100 ; short: M1x1tp0
			 ; hex set target position in hex (microstepp)
				exampes: motor 1 targetpos 0x100 ; short: M1x1tp0x0
		-currentpos(CP);<int,?>||<option>
			 ; ? get current position in float (stepp)
			 : ?x get current position in hex (microstepp)
			 ; int set current position in float (stepp)
				exampes: motor 1 current -100 ; short: M1x1tp0
			 ; hex set target position in hex (microstepp)
				exampes: motor 1 current 0x100 ; short: M1x1tp0x0
			 ; option=enable(1)  optionally update the encoder counter

*/

// 32 
#define HW 210

#define GO_BOOTLOAD PB4

#define VBUTTON_ALERT_RESET 0x01

extern uint8_t m_VirtualButton;


#if HW==210

#define SerialDebug SerialUSB

#else



#endif // HW==210



#define INPUT_SIZE 100






#define ERROR_PARAMETER 1
#define ERROR_SYNTAX 2
#define ERROR_NOHEX 3
#define ERROR_NOFLOAT 4
#define ERROR_NO_GET 5
#define ERROR_NO_SET 6
#define ERROR_MOTOR_IS_LOCKET 7
#define ERROR_NO_VALID_NUMMER 8




char* SkipSpaces(	 char * str);
int Find(	char * str,char ch);



// used in UserFunction.cpp
const char strCNotCreate_UserFunctionTask[] = { "C'not create user function task %u!" };
const char strCreate_UserFunctionTask[] = { "Create user function task %u!" };
const char strAutostartFunction[] = { "Autostart user function task %u!" };
const char strAutostartFunctionSub[] = { "Sub function %u!" };

const char strCNotCreate_MotorTask[] = { "C'not create motor task %u!" };
const char strCreate_MotorTask[] = { "Create create motor task %u!" };
const char strStart[] = { "start" };
const char strStop[] = { "stop" };
const char strExternStop[] = { "extern stop" };
const char strEnd[] = { "end" };










class CCmdDecode
{
private:
	uint8_t m_DirectInput : 1;
	int16_t m_NewChar ; 
public:
    CCmdDecode();
	static String GetToken_String(char **startStr, bool numLimit=true);
	static int GetToken_Int(char **startStr);
	static double GetToken_Float(char **startStr);
	
	void SetDirectInput(uint8_t mode) { m_DirectInput = mode; };
	bool DecodeCommandLine(char ch);
	
	static void PrintError(byte error);
	static void PrintMessage(const char* message, uint8_t nr);
	char *GetCmdLine() { return cmdLine; };
	void ResetCmdLine() { cmdLine[0] = 0; cmdLen = 0; };
	char cmdLine[INPUT_SIZE];
	int16_t Peek();
	byte cmdLen;
	
	
	
	
};	

extern CCmdDecode g_CmdDecode;

#endif