// Input.h

#ifndef _INPUT_h
#define _INPUT_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif


//#define INPUT_SENSOR1NC 0
//#define INPUT_SENSOR1NO 1
//#define INPUT_SENSOR2NC 2
//#define INPUT_SENSOR2NO 3
//#define INPUT_SENSOR3NC 4
//#define INPUT_SENSOR3NO 5
//#define INPUT_LASER1 6
//#define INPUT_LASER2 7



#define INPUT1 0
#define INPUT2 1
#define INPUT3 2
#define INPUT4 3
#define INPUT5 4
#define INPUT6 5
#define INPUT7 6
#define INPUT8 7
#define INPUT_N (INPUT8+1)

//#define g_Input1NO g_Input[INPUT_SENSOR1NO]
//#define g_Input1NC g_Input[INPUT_SENSOR1NC]
//#define g_Input2NO g_Input[INPUT_SENSOR2NO]
//#define g_Input2NC g_Input[INPUT_SENSOR2NC]
//#define g_Input3NO g_Input[INPUT_SENSOR3NO]
//#define g_Input3NC g_Input[INPUT_SENSOR3NC]


#define g_Input1 g_Input[INPUT1]
#define g_Input2 g_Input[INPUT2]
#define g_Input3 g_Input[INPUT3]
#define g_Input4 g_Input[INPUT4]
#define g_Input5 g_Input[INPUT5]
#define g_Input6 g_Input[INPUT6]

#define g_Input7 g_Input[INPUT7]
#define g_Input8 g_Input[INPUT8]


#define INPUT_RUN_NONE										0x000000
#define INPUT_RUN_USERFUNCTION_START_1						0x000100
#define INPUT_RUN_USERFUNCTION_START_2						0x000200
#define INPUT_RUN_USERFUNCTION_START_3						0x000400
#define INPUT_RUN_USERFUNCTION_START_4						0x000800
#define INPUT_RUN_USERFUNCTION_START_5						0x001000
#define INPUT_RUN_USERFUNCTION_START_6						0x002000
#define INPUT_RUN_USERFUNCTION_STOP_1						0x010100
#define INPUT_RUN_USERFUNCTION_STOP_2						0x010200
#define INPUT_RUN_USERFUNCTION_STOP_3						0x010400
#define INPUT_RUN_USERFUNCTION_STOP_4						0x010800
#define INPUT_RUN_USERFUNCTION_STOP_5						0x011000
#define INPUT_RUN_USERFUNCTION_STOP_6						0x012000

#define INPUT_RUN_MOTOR_STOP_1								0x020100
#define INPUT_RUN_MOTOR_STOP_2								0x020200
#define INPUT_RUN_MOTOR_STOP_1_2							0x020300
#define INPUT_RUN_MOTOR_STOP_3								0x020400
#define INPUT_RUN_MOTOR_STOP_1_3							0x020500
#define INPUT_RUN_MOTOR_STOP_2_3							0x020600
#define INPUT_RUN_MOTOR_STOP_1_2_3							0x020700
#define INPUT_RUN_MOTOR_STOP_4								0x020800
#define INPUT_RUN_MOTOR_STOP_1_4							0x020900
#define INPUT_RUN_MOTOR_STOP_2_4							0x020A00
#define INPUT_RUN_MOTOR_STOP_1_2_4							0x020B00
#define INPUT_RUN_MOTOR_STOP_3_4							0x020C00
#define INPUT_RUN_MOTOR_STOP_1_3_4							0x020D00
#define INPUT_RUN_MOTOR_STOP_2_3_4							0x020E00
#define INPUT_RUN_MOTOR_STOP_1_2_3_4						0x020F00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1						0x022100
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2						0x022200
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2					0x022300
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_3						0x022400
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_3					0x022500
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2_3					0x022600
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2_3					0x022700
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_4						0x022800
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_4					0x022900
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2_4					0x022A00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2_4					0x022B00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_3_4					0x022C00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_3_4					0x022D00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2_3_4					0x022E00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2_3_4				0x022F00



class InputClass
{
 protected:
	 uint8_t  m_Nr=0;
	 uint8_t  m_Pin = 0;
	 uint32_t  m_RunFaling = INPUT_RUN_NONE;
	 uint32_t  m_RunRising = INPUT_RUN_NONE;
	 void _Run(uint32_t mode);
 public:
	 void EEpromInitDefault(uint8_t nr, uint8_t mode);
	 uint8_t Init(uint8_t  nr, uint16_t pin, uint32_t triggerLow, uint32_t triggerHigh);
	 static uint8_t Init();
	 uint8_t Init(uint8_t  nr, uint16_t pin);
	void Run(uint8_t faling);
	void SetRunFalingFunction(uint32_t faling) { m_RunFaling = faling; };
	void SetRunRisingFunction(uint32_t rising) { m_RunRising = rising; };
	uint32_t GetRunRisingFunction() { return m_RunRising ; };
	uint32_t GetRunFalingFunction() { return m_RunFaling; };
	uint8_t GetStatus();
};

extern InputClass g_Input[INPUT_N];

#endif

