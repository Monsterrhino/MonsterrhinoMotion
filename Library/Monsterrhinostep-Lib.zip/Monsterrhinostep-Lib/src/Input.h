// Input.h

#ifndef _INPUT_h
#define _INPUT_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#define INPUT1 0
#define INPUT2 1
#define INPUT3 2
#define INPUT4 3
#define INPUT5 4
#define INPUT6 5
#define INPUT7 6
#define INPUT8 7
#define INPUT9 8
#define INPUT10 9
#define INPUT11 10
#define INPUT12 11

#define INPUT_N (INPUT12+1)

//both spellings are allowed
//g_Input1 == g_Input[0]
//g_Input4 == g_Input[3]
#define g_Input1 g_Input[INPUT1]
#define g_Input2 g_Input[INPUT2]
#define g_Input3 g_Input[INPUT3]
#define g_Input4 g_Input[INPUT4]
#define g_Input5 g_Input[INPUT5]
#define g_Input6 g_Input[INPUT6]
#define g_Input7 g_Input[INPUT7]
#define g_Input8 g_Input[INPUT8]
#define g_Input9 g_Input[INPUT9]
#define g_Input10 g_Input[INPUT10]
#define g_Input11 g_Input[INPUT11]
#define g_Input12 g_Input[INPUT12]

/*
* Defined values to choose an action
*		INPUT_RUN_
*				->NONE
*				->USERFUNCTION_
*							 ->START_[UserFunctionNr] + [SubFunctionNr]
*							 ->STOP_[UserFunctionNr]  +	[SubFunctionNr]
*				->MOTOR_
*							 ->STOP_(1)_(2)_(3)_(4)				//all combinations possible; e.g. _1 , _1_2_3, _2_3_4, _4, ...
*							 ->EMERGENCYSTOP_(1)_(2)_(3)_(4)	//all combinations possible
*/
#define INPUT_RUN_NONE										0x000000
#define INPUT_RUN_USERFUNCTION_START_1						0x000100
#define INPUT_RUN_USERFUNCTION_START_2						0x000200
#define INPUT_RUN_USERFUNCTION_START_3						0x000400
#define INPUT_RUN_USERFUNCTION_START_4						0x000800
#define INPUT_RUN_USERFUNCTION_START_5						0x001000
#define INPUT_RUN_USERFUNCTION_START_6						0x002000
#define INPUT_RUN_USERFUNCTION_STOP_1						0x010100
#define INPUT_RUN_USERFUNCTION_STOP_2						0x010200
#define INPUT_RUN_USERFUNCTION_STOP_3						0x010400
#define INPUT_RUN_USERFUNCTION_STOP_4						0x010800
#define INPUT_RUN_USERFUNCTION_STOP_5						0x011000
#define INPUT_RUN_USERFUNCTION_STOP_6						0x012000

#define INPUT_RUN_MOTOR_STOP_1								0x020100
#define INPUT_RUN_MOTOR_STOP_2								0x020200
#define INPUT_RUN_MOTOR_STOP_1_2							0x020300
#define INPUT_RUN_MOTOR_STOP_3								0x020400
#define INPUT_RUN_MOTOR_STOP_1_3							0x020500
#define INPUT_RUN_MOTOR_STOP_2_3							0x020600
#define INPUT_RUN_MOTOR_STOP_1_2_3							0x020700
#define INPUT_RUN_MOTOR_STOP_4								0x020800
#define INPUT_RUN_MOTOR_STOP_1_4							0x020900
#define INPUT_RUN_MOTOR_STOP_2_4							0x020A00
#define INPUT_RUN_MOTOR_STOP_1_2_4							0x020B00
#define INPUT_RUN_MOTOR_STOP_3_4							0x020C00
#define INPUT_RUN_MOTOR_STOP_1_3_4							0x020D00
#define INPUT_RUN_MOTOR_STOP_2_3_4							0x020E00
#define INPUT_RUN_MOTOR_STOP_1_2_3_4						0x020F00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1						0x022100
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2						0x022200
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2					0x022300
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_3						0x022400
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_3					0x022500
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2_3					0x022600
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2_3					0x022700
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_4						0x022800
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_4					0x022900
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2_4					0x022A00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2_4					0x022B00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_3_4					0x022C00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_3_4					0x022D00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_2_3_4					0x022E00
#define INPUT_RUN_MOTOR_EMERGENCYSTOP_1_2_3_4				0x022F00



class InputClass
{
 protected:
	 uint8_t  m_Nr=0;
	 uint8_t  m_Pin = 0;
	 uint32_t  m_RunFalling = INPUT_RUN_NONE;
	 uint32_t  m_RunRising = INPUT_RUN_NONE;
	 void _Run(uint32_t mode);
 public:
	 void EEpromInitDefault(uint8_t nr, uint8_t mode);
	 uint8_t Init(uint8_t  nr, uint16_t pin, uint32_t TriggerLow, uint32_t TriggerHigh);
	 static uint8_t Init();
	 uint8_t Init(uint8_t  nr, uint16_t pin);
	void Run(uint8_t falling);
	/**
	* @brief	Activates interrupt on falling edge of input.
	* @param	falling: Action to be Triggered
	*/
	void SetRunFallingFunction(uint32_t falling) { m_RunFalling = falling; };

	/**
	* @brief	Activates interrupt on rising edge of input.
	* @param	rising: Action to be Triggered
	*/
	void SetRunRisingFunction(uint32_t rising) { m_RunRising = rising; };

	/**
	* @brief	Reads the action, assigned to the specified input, when rising.
	* @return	Action
	*/
	uint32_t GetRunRisingFunction() { return m_RunRising; };

	/**
	* @brief	Reads the action, assigned to the specified input, when falling.
	* @return	Action
	*/
	uint32_t GetRunFallingFunction() { return m_RunFalling; };
	//static void InterruptInput1();
	/**
	* @brief	Reads the value of the specified input, either HIGH or LOW
	* @return	HIGH or LOW
	*/
	uint8_t GetStatus();
};

extern InputClass g_Input[INPUT_N];

#endif

