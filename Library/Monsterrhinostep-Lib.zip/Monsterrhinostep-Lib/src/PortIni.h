#pragma once


#define  PIN_SPI1_CLK	PB3
#define  PIN_SPI1_MISO	PB4
#define  PIN_SPI1_MOSI	PB5

#define PIN_DIAG0_SWN1	PC13
#define PIN_SPI1_NSS0	PC14
#define PIN_DRV_ENN1	PB7

#define PIN_DIAG0_SWN2	PC11
#define PIN_SPI1_NSS1	PD2
#define PIN_DRV_ENN2	PC10

#define PIN_DIAG0_SWN3	PB14
#define PIN_SPI1_NSS2	PA8
#define PIN_DRV_ENN3	PB13

#define PIN_DIAG0_SWN4	PB10
#define PIN_SPI1_NSS3	PA15
#define PIN_DRV_ENN4	PB2

#define PIN_INPUT_1	PA0
#define PIN_INPUT_2	PA1
#define PIN_INPUT_3	PA2
#define PIN_INPUT_4	PA3
#define PIN_INPUT_5	PA4
#define PIN_INPUT_6	PA5
#define PIN_INPUT_7	PA6
#define PIN_INPUT_8	PA7

#define  LED_PIN		PB6

#define PIN_SEL1 PC15
#define PIN_SEL2 PC12
#define PIN_SEL3 PC9
#define PIN_SEL4 PB11

#define PIN_BORD_ID0 PC4
#define PIN_BORD_ID1 PC5
#define PIN_DOOR_CTRL_SIG PC1
#define PIN_DOOR_LATCH_STATUS PC2
#define PIN_DOOR_STATUS PC3

#define PIN_PWM_1 PC8
#define PIN_PWM_2 PC7
#define PIN_PWM_3 PC6