// Motor.h

#ifndef _MOTOR_h
#define _MOTOR_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "arduino.h"
#else
#include "WProgram.h"
#endif
#include <STM32FreeRTOS.h>
//#include <TMC5160/TMC5160.h>
#include <TMC5160/TMC5160_registers.h>

//#include <TMC5160/TMC5160_SPI_STM32.h>
#include <MotorIoEvent.h>
#include <ResourceLock.h>
#include <System.h>
#include <SPI.h>

#define MOTOR_N 4



#define MOTOR_FUNCTION_NONE				0
#define MOTOR_FUNCTION_INIT				1
#define MOTOR_FUNCTION_HOMING			2
#define MOTOR_FUNCTION_TUNEPOWERSTAGE	100
#define MOTOR_FUNCTION_STEALTHCHOP2		101
#define MOTOR_FUNCTION_STEALGUARD2		102





#define DEFAULT_DRIVER_drvStrength 0
#define DEFAULT_DRIVER_bbmTime		8
#define DEFAULT_DRIVER_bbmClks		0
#define DEFAULT_DRIVER_senseResistor				220
#define DEFAULT_motorCurrent						1000
#define DEFAULT_motorCurrentReduction				0
#define DEFAULT_freewheeling						TMC5160_Reg::FREEWHEEL_NORMAL
#define DEFAULT_iholddelay							7	
#define DEFAULT_pwmOfsInitial						150
#define DEFAULT_pwmGradInitial						30
#define DEFAULT_stepperDirection					1
#define DEFAULT_motorSteps							200

#define DEFAULT_PWMTHRS								0.0
#define DEFAULT_COOLTHRS							0.0
#define DEFAULT_HIGHTHRS							0.0
#define DEFAULT_SWMODE								0
#define DEFAULT_RAMPMODE							POSITIONING_MODE
#define DEFAULT_MAXSPEED							200.0
#define DEFAULT_RAMPSPEEDS_START					0.0
#define DEFAULT_RAMPSPEEDS_STOP						0.1
#define DEFAULT_RAMPSPEEDS_HOLD						100.0
#define DEFAULT_ACCELERATIONS_AMAX					250.0
#define DEFAULT_ACCELERATIONS_DMAX					350.0
#define DEFAULT_ACCELERATIONS_A1					500.0
#define DEFAULT_ACCELERATIONS_D1					700.0
#define DEFAULT_HOMING_MODE							0
#define DEFAULT_HOMING_OFFSET						0.0
#define DEFAULT_ENCODER_RESOLUTION					0
#define DEFAULT_ENCODER_ALLOWEDDEVIATION			0
#define DEFAULT_ENCODER_SETUP						0
#define DEFAULT_ENCODER_INVERTED					0
#define DEFAULT_HOMING_MAXPOS						1000000
#define DEFAULT_HOMING_TIMEOUT						100000
#define DEFAULT_HOMING_SPEED2						10
#define DEFAULT_HOMING_accelerationsDmax			(DEFAULT_ACCELERATIONS_D1*3)

//Both spellings are allowed
// g_Motor1 == g_Motor[0]
// g_Motor4 == g_Motor[3]
#define g_Motor1 g_Motor[0]
#define g_Motor2 g_Motor[1]
#define g_Motor3 g_Motor[2]
#define g_Motor4 g_Motor[3]

#define MOTOR1 0
#define MOTOR2 1
#define MOTOR3 2
#define MOTOR4 3


class HomingParameters {
public:
	uint8_t mode = 0;										//homing on the left (1) or right (2) side. 0 is homing off.
	uint32_t timeOut = DEFAULT_HOMING_TIMEOUT;				//Timeout without successful homing
	uint32_t maxPos = DEFAULT_HOMING_MAXPOS;				//Maximal position without successful homing  (in microsteps)
	float rampSpeed = DEFAULT_MAXSPEED;						//Initial speed in homing; default is Default_MaxSpeed
	float rampSpeed_2 = DEFAULT_HOMING_SPEED2;				//Speed after first contact with limitSW
	double  homingOffset = 0;								//Offset from actual switch position
	float rampSpeedStart = DEFAULT_RAMPSPEEDS_START;
	float rampSpeedStop = DEFAULT_RAMPSPEEDS_STOP;
	float rampSpeedHold = DEFAULT_RAMPSPEEDS_HOLD;
	float accelerationsAmax = DEFAULT_ACCELERATIONS_AMAX;
	float accelerationsDmax = DEFAULT_ACCELERATIONS_DMAX;
	float accelerationsA1 = DEFAULT_ACCELERATIONS_A1;
	float accelerationsD1 = DEFAULT_ACCELERATIONS_D1;
	bool multiple_homing = true;
	void LoadfromEEprom(void* motor);


};





class MotorClass
{
private:
	uint8_t _CS;
	SPISettings _spiSettings;
	SPIClass* _spi;

	void _beginTransaction();
	void _endTransaction();
	uint32_t _fclk;
public:
	uint32_t readRegister(uint8_t address);	// addresses are from TMC5160.h
	uint32_t readRegisterTest(uint8_t address);
	uint8_t  writeRegister(uint8_t address, uint32_t data);
	uint8_t  readStatus();
	uint8_t Init();
protected:
	int8_t  m_Nr = -1;				// IC driver nr 0..(MOTOR_N-1)

	uint16_t m_InterruptOutPin = 0;		// interrupt Output Pin

	uint16_t  m_EnablePin = 0;
	int32_t m_MaxRampSpeed = 0;
	int32_t m_AccelerationAmax = 0;
	int32_t m_AccelerationA1 = 0;
	int32_t m_AccelerationDmax = 0;
	int32_t m_AccelerationD1 = 1;
	int32_t m_RampSpeedsStart = 0;
	int32_t m_RampSpeedsStop = 10;
	int32_t m_RampSpeedsHold = 0;
	int32_t m_ModeChangeSpeedsPwmThrs = 0;
	int32_t m_ModeChangeSpeedsHighThrs = 0;
	int32_t m_ModeChangeSpeedsCoolThrs = 0;
	int16_t m_MotorSteps = 200;
	int16_t m_EncResolution = 0;
	uint16_t m_EncoderIndexConfiguration = 0;
	uint8_t m_EncoderLatching : 1;
	uint32_t m_COOLCONF_Register = 0;

public:
	static constexpr uint8_t IC_VERSION = 0x30;
	enum Command {
		CurrentPosition, EncoderPosition, LatchedPosition, LatchedEncoderPosition, TargetPosition, CurrentSpeed,
		MaxSpeed, RampSpeedsStart, RampSpeedsStop, RampSpeedsHold, Acceleration, AccelerationAMAX, AccelerationDMAX, AccelerationA1, AccelerationD1,
		ModeChangeSpeeds1, ModeChangeSpeeds2, ModeChangeSpeeds3, MoveRelative
	};
	enum MotorDirection { NORMAL_MOTOR_DIRECTION = 0x00, INVERSE_MOTOR_DIRECTION = 0x1 };
	enum RampMode { POSITIONING_MODE, VELOCITY_MODE, HOLD_MODE };


	struct PowerStageParameters {
		uint8_t drvStrength = 2; // MOSFET gate driver current (0 to 3)
		uint8_t bbmTime = 0; // "Break Before Make" duration specified in ns (0 to 24)
		uint8_t bbmClks = 4; // "Break Before Make" duration specified in clock cycles (0 to 15).
	};

	struct MotorParameters {
		uint16_t globalScaler = 48; // global current scaling (32 to 256)
		uint8_t irun = 16; // motor run current (0 to 31). For best performance don't set lower than 16
		uint8_t ihold = 0; // standstill current (0 to 31). Set 70% of irun or lower.
		TMC5160_Reg::PWMCONF_freewheel_Values freewheeling = TMC5160_Reg::FREEWHEEL_NORMAL; // Freewheeling / passive braking of ihold = 0
		uint8_t pwmOfsInitial = 30; // initial stealthChop PWM amplitude offset (0-255)
		uint8_t pwmGradInitial = 0; // initial stealthChop velocity dependent gradient for PWM amplitude
	};

	struct MotorSetup {
		uint16_t senseResistor = DEFAULT_DRIVER_senseResistor; //Sense resistors value mOhms
		uint16_t motorCurrent = DEFAULT_motorCurrent;	//Motor phase current mA 
		uint16_t motorCurrentReduction = DEFAULT_motorCurrentReduction;	//Motor current standstill  current mA // 0 =FREEWHEEL NORMAL ; -1 = FREEWHEEL ENABLED; -2 = FREEWHEEL SHORT LS 
		TMC5160_Reg::PWMCONF_freewheel_Values freewheeling = TMC5160_Reg::FREEWHEEL_NORMAL; // Freewheeling / passive 
		uint8_t iholddelay = 7;
		uint8_t pwmOfsInitial = 30; // initial stealthChop PWM amplitude offset (0-255)
		uint8_t pwmGradInitial = 0; // initial stealthChop velocity dependent gradient for PWM amplitude
		//uint32_t coolConf = 0;
	};







	struct MotorSetupSave {
		PowerStageParameters powerStageParameters;
		MotorClass::MotorSetup motorSetup;
		uint8_t stepperDirection = 1;
	};

	ResourceLockClass m_Lock;
	TMC5160_Reg::RAMP_STAT_Register m_RampStatus = { 0 };
	uint8_t Init(
		uint8_t  nr,				// IC driver nr 
		uint16_t enablePin,		// driver outut Enable
		uint16_t intOutPin,		// interrupt Output Pin
		uint16_t chipSelectPin,	// pin to use for the SPI bus SS line
		uint16_t sclk = PA5,
		uint16_t miso = PA6,
		uint16_t mosi = PA7,
		uint32_t fclk = DEFAULT_F_CLK,
		const SPISettings& spiSettings = SPISettings(1000000, MSBFIRST, SPI_MODE0), // spi bus settings to use
		SPIClass& spi = SPI); // spi class to use



	HomingParameters m_HomingParameters;
	uint8_t m_LookUserTask = 0;
	uint8_t m_LookUserTaskSub = 0;

	///Return digital value of the motor interrupt pin, else -1
	int GetInterruptPin() { if (m_InterruptOutPin) return digitalRead(m_InterruptOutPin); else return -1; };
	void MotorFunction();
	MotorClass();

	/**
	* @brief	Convert steps to micro steps
	* @param	value: double/float value of steps (e.g. 4.54)
	* @return	value*(microsteps/step)
	*/
	int32_t SteppToMStepp(double value);

	/**
	* @brief	Convert micro steps to steps
	* @param	value: int value of microsteps (e.g. 454)
	* @return	value/(microsteps/step)
	*/
	double MSteppToStepp(int32_t value);


	bool Begin(MotorSetupSave motorSetupSave);
	bool Begin() { return Begin(m_MotorSetupSave); };

	/**
	 * @brief	Stop the current motion according to the set ramp mode and motion parameters.
	 * The max speed and start speed are set to 0 but the target position stays unchanged.
	 */
	void Stop(); //* Stop the current motion according to the set ramp mode and motion parameters. The max speed and start speed are set to 0 but the target position stays unchanged.


	/**
	* @brief	Motor-driver state
	* @param	enable: wanted driver state (true=enabled ; false=disabled, all bridges off)
	*/
	void Enable(uint8_t enable);

	/**
	* @brief	Return enable status of motor
	* @return	true if motor is enabled; false if disabled
	*/
	uint8_t IsEnable();

	///Sets up startup motor parameters with different modes (mode)
	void  EEpromInitDefault(uint8_t mode);

	///Save motor parameters as startupParameters to EEPROM
	void SaveMotorParameter();
	///Load startup motor parameters
	void  LoadMotorParameter();

	void StartUpTestController(uint8_t nr);

	MotorSetupSave m_MotorSetupSave;
	MotorIoEventClass m_MotorIoEvent;
	TaskHandle_t m_pxCreatedTask;

	/**
	* @brief	Wait specified time (timeout)
	* @param	timeout: time
	* @TODO	Userfunction_exit or Userfunction_Trigger sensible ?
	*/
	uint32_t MotorFunction_WaitEvent(uint32_t timeout = portMAX_DELAY);

	/**
	* @brief	Starts a motor function:
	* @param	sub: MOTOR_FUNCTION_HOMING, MOTOR_FUNCTION_INIT, MOTOR_FUNCTION_TUNEPOWERSTAGE, MOTOR_FUNCTION_TUNEPOWERSTAGE, MOTOR_FUNCTION_STEALTHCHOP2, MOTOR_FUNCTION_STEALGUARD2, MOTOR_FUNCTION_NONE
	*/
	void MotorFunction_TriggerStart(uint32_t sub);
	/**
	* @brief Stops a motor function:
	* MOTOR_FUNCTION_HOMING, MOTOR_FUNCTION_INIT, MOTOR_FUNCTION_TUNEPOWERSTAGE, MOTOR_FUNCTION_TUNEPOWERSTAGE, MOTOR_FUNCTION_STEALTHCHOP2, MOTOR_FUNCTION_STEALGUARD2, MOTOR_FUNCTION_NONE
	*/
	void MotorFunction_TriggerStop();

	///Return MotorParameters of motorSetup
	MotorClass::MotorParameters GetMotorParameter(MotorSetup motorSetup);
	///Set MotorParameter of motorSetup 
	MotorClass::MotorParameters SetMotorParameter(MotorSetup motorSetup);

	///0=Normal operation; 1= freewheeling; 2 = Coil shorted using LS drivers; 3 = Coil shorted using HS drivers
	void  SetFreewheelingMode(uint8_t mode = 1);
	///return: 0=Normal operation; 1= freewheeling; 2 = Coil shorted using LS drivers; 3 = Coil shorted using HS drivers
	uint8_t GetFreewheelingMode();

	TMC5160_Reg::RAMP_STAT_Register GetResetEvents();

	///Return max motor RMS current according to senseResistor
	static float GetMotorMaxRmsCurrent(uint32_t senseResistor);

	///Return the current speed (steps / second)
	double GetCurrentSpeed();
	///Return the current speed (steps / second)
	int32_t GetCurrentSpeedInt();

	///Sets target position in microsteps. Set all other motion profile parameters before
	void SetTargetPositionInt(int32_t position);
	///Sets target position in microsteps. Set all other motion profile parameters before
	void SetTargetPosition(double position);

	///Return target position (integer)
	int32_t GetTargetPositionInt();
	///Return target position (double)
	double GetTargetPosition();

	///Set current position, optional updateEncoderPosition
	void SetCurrentPosition(double position, bool updateEncoderPos = false);
	///Set current position (integer), optional updateEncoderPosition
	void SetCurrentPositionInt(int32_t position, bool updateEncoderPos = false);

	///Return current position (integer)
	int32_t GetCurrentPositionInt();
	///Return current position
	double GetCurrentPosition();

	//------------------ENCODER
	///Set current position to 0 TODO CHECK
	void Set0Position(double position, bool updateEncoderPos = false);
	///Return encoder position
	double GetEncoderPosition();
	///Return encoder position (integer)
	int32_t GetEncoderPositionInt();
	///
	double GetLatchedPosition();
	///
	int32_t GetLatchedPositionInt();
	///
	double GetLatchedEncoderPosition();
	///
	int32_t GetLatchedEncoderPositionInt();
	//--------------------------
	///Sets max Acceleration to maxAccel
	void SetAcceleration_AMAX(double maxAccel);
	///Sets max Acceleration to maxAccel
	void SetAcceleration_AMAX_Int(uint32_t maxAccel);

	///return max Acceleration
	double GetAcceleration_AMAX();
	///return max Acceleration
	uint32_t GetAcceleration_AMAX_Int();

	///Sets max Deceleration to maxDecel
	void SetAcceleration_DMAX(double maxDecel);
	///Sets max Deceleration to maxDecel
	void SetAcceleration_DMAX_Int(uint32_t maxDecel);

	///return max Deceleration
	double GetAcceleration_DMAX();
	///return max Deceleration
	uint32_t GetAcceleration_DMAX_Int();

	///Sets start Acceleration to startAccel
	void SetAcceleration_A1(double startAccel);
	///Sets start Acceleration to startAccel
	void SetAcceleration_A1_Int(uint32_t startAccel);

	///return start acceleration
	double GetAcceleration_A1();
	///return start acceleration (integer)
	uint32_t GetAcceleration_A1_Int();

	///Set final Deceleration to finalDecel
	void SetAcceleration_D1(double finalDecel);
	///Set final Deceleration to finalDecel
	void SetAcceleration_D1_Int(uint32_t finalDecel);

	///return final Deceleration
	double GetAcceleration_D1();
	///return final Deceleration
	uint32_t GetAcceleration_D1_Int();

	///Set A1,D1,Amax,Dmax to value
	void SetAcceleration(double value);
	///Set A1,D1,Amax,Dmax to value
	void SetAccelerationInt(uint32_t value);

	///max Acceleration, max Deceleration, start Acceleration, final Deceleration
	void SetAccelerations(double maxAccel, double maxDecel, double startAccel, double finalDecel);
	///max Acceleration, max Deceleration, start Acceleration, final Deceleration
	void SetAccelerationsInt(uint32_t maxAccel, uint32_t maxDecel, uint32_t startAccel, uint32_t finalDecel);

	///mode is VELOCITY,POSITIONING or HOLD
	void SetRampMode(MotorClass::RampMode mode);
	///return VELOCITY,POSITIONING or HOLD
	uint32_t  GetRampMode();
	///sets maximum speed (0-255?)
	void SetMaxSpeed(double speed);
	///sets maximum speed (0-255?)
	void SetMaxSpeedInt(int speed);
	///return maximum speed (0-255?)
	double GetMaxSpeed();
	///return maximum speed (0-255?)
	int GetMaxSpeedInt();

	///sets ramp speed start
	void SetRampSpeedStart(double startSpeed);
	///sets ramp speed start
	void SetRampSpeedStartInt(uint32_t startSpeed);
	///sets ramp speed start
	double GetRampSpeedStart();
	///sets ramp speed start
	int GetRampSpeedStartInt();

	///sets ramp speed stop
	void SetRampSpeedStop(double stopSpeed);
	///sets ramp speed stop
	void SetRampSpeedStopInt(uint32_t stopSpeed);
	///return ramp speed stop
	double GetRampSpeedStop();
	///return ramp speed stop
	int GetRampSpeedStopInt();

	///sets ramp speed hold
	void SetRampSpeedHold(double holdSpeed);
	///sets ramp speed hold
	void SetRampSpeedHoldInt(uint32_t holdSpeed);
	///return ramp speed hold
	double GetRampSpeedHold();
	///return ramp speed hold
	int GetRampSpeedHoldInt();

	//sets start Speed, stop Speed, hold Speed
	void SetRampSpeeds(double startSpeed, double stopSpeed, double transitionSpeed);
	//sets start Speed, stop Speed, hold Speed
	void SetRampSpeedsInt(uint32_t startSpeed, uint32_t stopSpeed, uint32_t transitionSpeed);


	void SetModeChangeSpeedsInt(uint32_t pwmThrs, uint32_t coolThrs, uint32_t highThrs);

	void SetModeChangeSpeeds_TpwmThrs_Int(uint32_t pwmThrs);
	uint32_t GetModeChangeSpeeds_TpwmThrs_Int();
	void SetModeChangeSpeeds_CoolThrs_Int(uint32_t coolThrs);
	uint32_t GetModeChangeSpeeds_CoolThrs_Int();
	void SetModeChangeSpeeds_HighThrs_Int(uint32_t highThrs);
	uint32_t GetModeChangeSpeeds_HighThrs_Int();
	void SetModeChangeSpeeds_TpwmThrs(double pwmThrs);
	double GetModeChangeSpeeds_TpwmThrs();
	void SetModeChangeSpeeds_CoolThrs(double coolThrs);
	double GetModeChangeSpeeds_CoolThrs();
	void SetModeChangeSpeeds_HighThrs(double highThrs);
	double GetModeChangeSpeeds_HighThrs();
	void SetModeChangeSpeeds(double pwmThrs, double coolThrs, double highThrs);

	///Set position relative from current position
	void SetMoveRelativeInt(int32_t pos);
	///Set position relative from current position
	void SetMoveRelative(double pos);

	/**
	* @brief	Execute an emergency stop.
	* All mosfets are powered down, controls are still powered. If no parameter, reset is false by default.
	* @param	reset: true activates emergency stop; false reactivates machine
	*/
	void EmergencyStop(uint8_t reset = false);

	///Get Switch mode register configuration
	uint32_t GetSW_ModeInt();
	///Set Switch mode register configuration 
	void SetSW_ModeInt(uint32_t);
	///Get Switch mode register configuration
	TMC5160_Reg::SW_MODE_Register GetSW_Mode();
	///Set Switch mode register configuration
	void SetSW_Mode(TMC5160_Reg::SW_MODE_Register);

	uint32_t GetDrvStatusInt(); //  Get Drver status
	TMC5160_Reg::DRV_STATUS_Register GetDrvStatus();

	uint32_t GetRampStatusInt(); // Get RAMP STATUS
	TMC5160_Reg::RAMP_STAT_Register GetRampStatus(); // Get RAMP STATUS

	/**
	* @brief	Reset ramp status
	* TODO
	* @param	value:
	*/
	void ResetRampStatus(uint32_t value = 0xffff); // Reset RAMP STATUS

	TMC5160_Reg::COOLCONF_Register GetCOOLCONF();
	uint32_t GetCOOLCONFInt();
	void SetCOOLCONF(TMC5160_Reg::COOLCONF_Register value);
	void SetCOOLCONFInt(uint32_t value);

	uint32_t GetGstatInt();
	TMC5160_Reg::GSTAT_Register GetGstat();
	void ResetGstatInt(uint32_t gStat);
	void  ResetGstat(TMC5160_Reg::GSTAT_Register gStat);
	//uint32_t GetGStat();	 
	//void SetGStat(uint32_t value);

		 /**
		 * @brief	Set encoder resolution
		 * Set the encoder constant to match the motor and encoder resolutions.
		 * This function will determine if the binary or decimal mode should be used
		 * and return false if no exact match could be found (for example for an encoder
		 * with a resolution of 360 and a motor with 200 steps per turn). In this case
		 * the best approximation in decimal mode will be used.
		 * @param	motorSteps: the number of steps per turn for the motor
		 * @param	encResolution: the actual encoder resolution (pulses per turn); when negative its inverted
		 * @return true if an exact match was found, false otherwise
		 */
	bool SetEncoderResolution(int motorSteps, int encResolution);

	int GetEncoderResolution() {
		return m_EncResolution;
	};

	/**
	* @brief	Configure the encoder N event context
	* @param	sensitivity : set to one of ENCODER_N_NO_EDGE, ENCODER_N_RISING_EDGE, ENCODER_N_FALLING_EDGE, ENCODER_N_BOTH_EDGES
	* @param	nActiveHigh : choose N signal polarity (true for active high)
	* @param	ignorePol : if true, ignore A and B polarities to validate a N event
	* @param	aActiveHigh : choose A signal polarity (true for active high) to validate a N event
	* @param	bActiveHigh : choose B signal polarity (true for active high) to validate a N event
	*/
	void SetEncoderIndexConfiguration(TMC5160_Reg::ENCMODE_sensitivity_Values sensitivity, bool nActiveHigh = true, bool ignorePol = true, bool aActiveHigh = false, bool bActiveHigh = false);
	uint32_t GetEncoderIndexConfiguration() { return m_EncoderIndexConfiguration; };

	/**
	* Enable/disable encoder and position latching on each encoder N event (on each revolution)
	* The difference between the 2 positions can then be compared regularly to check
	* for an external step loss.
	*/
	void SetEncoderLatching(bool enabled);
	bool GetEncoderLatching() { return m_EncoderLatching; };

	/* Set maximum number of steps between internal position and encoder position
	 * before Triggering the deviation flag.
	 * Set to 0 to disable. */

	 /// Check if a deviation between internal pos and encoder has been detected */
	bool IsEncoderDeviationDetected();

	/// Clear encoder deviation flag (deviation condition must be handled before) */
	void ClearEncoderDeviationFlag();

	///Value?
	void SetMotorSteps(uint32_t nr) { m_MotorSteps = nr; };
	///Value?
	uint32_t GetMotorSteps() { return m_MotorSteps; };


	uint32_t GetStartup_drvStrength();
	void  SetStartup_drvStrength(uint32_t value);

	uint32_t GetStartup_bbmTime();
	void  SetStartup_bbmTime(uint32_t value);

	uint32_t GetStartup_bbmClks();
	void  SetStartup_bbmClks(uint32_t value);

	uint32_t GetStartup_SenseResistor();
	void  SetStartup_SenseResistor(uint32_t value);

	uint32_t GetStartup_MotorCurrent();
	void  SetStartup_MotorCurrent(uint32_t value);

	uint32_t GetStartup_MotorCurrentReduction();
	void  SetStartup_MotorCurrentReduction(uint32_t value);

	uint32_t GetStartup_Freewheeling();
	void  SetStartup_Freewheeling(uint32_t value);

	uint32_t GetStartup_Iholddelay();
	void  SetStartup_Iholddelay(uint32_t value);

	uint32_t GetStartup_PwmOfsInitial();
	void  SetStartup_PwmOfsInitial(uint32_t value);

	uint32_t GetStartup_PwmGradInitial();
	void  SetStartup_PwmGradInitial(uint32_t value);

	uint32_t GetStartup_StepperDirection();
	void  SetStartup_StepperDirection(uint32_t value);

	uint32_t GetStartup_MotorSteps();
	void  SetStartup_MotorSteps(uint32_t value);

	uint32_t GetStartup_PWMThrsInt();
	double GetStartup_PWMThrs();
	void SetStartup_PWMThrsInt(uint32_t value);
	void  SetStartup_PWMThrs(double value);

	uint32_t GetStartup_COOLThrsInt();
	double GetStartup_COOLThrs();
	void  SetStartup_COOLThrsInt(uint32_t value);
	void  SetStartup_COOLThrs(double value);

	double GetStartup_HighThrs();
	uint32_t GetStartup_HighThrsInt();
	void  SetStartup_HighThrsInt(uint32_t value);
	void  SetStartup_HighThrs(double value);

	uint32_t GetStartup_SWMode();
	void  SetStartup_SWMode(uint32_t value);

	uint32_t GetStartup_RampMode();
	void  SetStartup_RampMode(uint32_t value);

	float GetStartup_RampMaxSpeed();
	void  SetStartup_RampMaxSpeed(float value);
	uint32_t GetStartup_RampMaxSpeedInt();
	void  SetStartup_RampMaxSpeedInt(uint32_t value);

	uint32_t GetStartup_RampSpeedsStartInt();
	void  SetStartup_RampSpeedsStartInt(uint32_t value);
	float GetStartup_RampSpeedsStart();
	void  SetStartup_RampSpeedsStart(float value);

	uint32_t GetStartup_RampSpeedsHoldInt();
	void  SetStartup_RampSpeedsHoldInt(uint32_t value);
	float GetStartup_RampSpeedsHold();
	void  SetStartup_RampSpeedsHold(float value);

	uint32_t GetStartup_RampSpeedsStopInt();
	void  SetStartup_RampSpeedsStopInt(uint32_t value);
	float GetStartup_RampSpeedsStop();
	void  SetStartup_RampSpeedsStop(float value);

	uint32_t GetStartup_AccelerationsAMaxInt();
	void  SetStartup_AccelerationsAMaxInt(uint32_t value);
	float GetStartup_AccelerationsAMax();
	void  SetStartup_AccelerationsAMax(float value);

	uint32_t GetStartup_AccelerationsDMaxInt();
	void  SetStartup_AccelerationsDMaxInt(uint32_t value);
	float GetStartup_AccelerationsDMax();
	void  SetStartup_AccelerationsDMax(float value);

	uint32_t GetStartup_AccelerationsA1Int();
	void  SetStartup_AccelerationsA1Int(uint32_t value);
	float GetStartup_AccelerationsA1();
	void  SetStartup_AccelerationsA1(float value);

	uint32_t GetStartup_AccelerationsD1Int();
	void  SetStartup_AccelerationsD1Int(uint32_t value);
	float GetStartup_AccelerationsD1();
	void  SetStartup_AccelerationsD1(float value);

	uint32_t GetStartup_COOLCONF();
	void SetStartup_COOLCONF(uint32_t value);

	//----------------------------------------------------
	//----------------------------------------------------
	//Homing-Startup-Parameters

	uint32_t GetStartup_HomingMode();
	void  SetStartup_HomingMode(uint32_t value);

	uint32_t GetStartup_HomingOffsetInt();
	void  SetStartup_HomingOffsetInt(uint32_t value);
	double GetStartup_HomingOffset();
	void  SetStartup_HomingOffset(double value);

	uint32_t GetStartup_HomingMaxPos();
	void SetStartup_HomingMaxPos(uint32_t value);

	uint32_t GetStartup_HomingTimeout();
	void  SetStartup_HomingTimeout(uint32_t value);

	uint32_t GetStartup_HomingSpeed2Int();
	void  SetStartup_HomingSpeed2Int(uint32_t value);
	float GetStartup_HomingSpeed2();
	void  SetStartup_HomingSpeed2(float value);

	uint32_t GetStartup_HomingDmaxInt();
	void  SetStartup_HomingDmaxInt(uint32_t value);
	float GetStartup_HomingDmax();
	void  SetStartup_HomingDmax(float value);

	//----------------------------------------------------
	//----------------------------------------------------
	// Encoder functions

	uint32_t GetStartup_EncoderResolution();
	void  SetStartup_EncoderResolution(uint32_t value);

	uint32_t GetStartup_EncoderAlloweddeviation();
	void  SetStartup_EncoderAlloweddeviation(uint32_t value);

	uint32_t GetStartup_EncoderSetup();
	void  SetStartup_EncoderSetup(uint32_t value);

	uint32_t GetStartup_EncoderInverted();
	void  SetStartup_EncoderInverted(uint32_t value);

	void SetEncoderAllowedDeviation(int steps);

	//----------------------------------------------------


	///Set motor current in mA
	void  SetMotorCurrent(uint32_t current_mA);
	///Return motor current in mA
	uint32_t  GetMotorCurrent() { return m_MotorSetupSave.motorSetup.motorCurrent; };

	///Set motor hold current in mA
	void  SetMotorCurrentHold(uint32_t current_mA);
	///Return motor hold current in mA
	uint32_t  GetMotorCurrentHold() { return m_MotorSetupSave.motorSetup.motorCurrentReduction; };

	///Set sense Resistor in mOhm
	void  SetMotorSenseResistor(uint32_t senseResistor);
	///Return sense Resistor in mOhm
	uint32_t  GetMotorSenseResistor() { return m_MotorSetupSave.motorSetup.senseResistor; };

	///Set motor Ihold delay (power down ramp time)
	void  SetMotorIholddelay(uint32_t iholddelay);
	///Return motor Ihold delay (power down ramp time)
	uint32_t  GetMotorIholddelay() { return m_MotorSetupSave.motorSetup.iholddelay; };

	///Return motor number
	uint8_t GetMotorNr() { return m_Nr; };
	///Set micro step resolution, values from 1 to 256?	TODO
	void SetMicroStepRes(uint16_t enable);
	///Return micro step resolution (microsteps / step)
	uint16_t GetMicroStepRes();

	eTaskState m_MotorFunctionStatus = eTaskState::eInvalid;
	long ThrsSpeedToTstep(double thrsSpeed) { return thrsSpeed != 0.0 ? (long)constrain((double)_fclk / (thrsSpeed * 256.0), 0, 1048575) : 0; }
	double ThrsSpeedTstepToSpeed(long thrs) { return (double)thrs * _fclk / 256.0; };

	// Following �14.1 Real world unit conversions
	// v[Hz] = v[5160A] * ( f CLK [Hz]/2 / 2^23 )
	double SpeedToHz(long speedInternal) { return ((double)speedInternal * (double)_fclk / (double)(1 << 24) / (double)_uStepCount); }
	long SpeedFromHz(double speedHz) { return (long)(speedHz / ((double)_fclk / (double)(1 << 24)) * (double)_uStepCount); }

	// Following �14.1 Real world unit conversions
	// a[Hz/s] = a[5160A] * f CLK [Hz]^2 / (512*256) / 2^24
	long AccelFromHz(double accelHz) { return (long)(accelHz / ((double)_fclk * (double)_fclk / (512.0 * 256.0) / (double)(1 << 24)) * (double)_uStepCount); }
	double AccelToHz(long accel) { return (double)(accel * ((double)_fclk * (double)_fclk / (512.0 * 256.0) / (double)(1 << 24)) / (double)_uStepCount); }

	uint8_t GetLimitSwitchLeft() { return GetRampStatus().status_stop_l ? 1 : 0; };
	uint8_t GetLimitSwitchRigth() { return GetRampStatus().status_stop_r ? 1 : 0; };


protected:
	static constexpr uint8_t WRITE_ACCESS = 0x80;	//Register write access for spi / uart communication
	static constexpr uint32_t DEFAULT_F_CLK = 12000000; // Typical internal clock frequency in Hz.

	bool _lastRegisterReadSuccess = false;
	TMC5160_Reg::CHOPCONF_Register _chopConf = { 0 }; //CHOPCONF register (saved here to be restored when disabling / enabling driver)
	uint16_t _uStepCount = 256; // Number of microsteps per step
	// See �12 Velocity based mode control

	RampMode _currentRampMode;
	void  SetFreewheelingModeEx(MotorSetup mode);
};

extern MotorClass g_Motor[MOTOR_N];

#endif
