// Motor.h

#ifndef _MOTOR_h
#define _MOTOR_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif
#include <STM32FreeRTOS.h>
//#include <TMC5160/TMC5160.h>
#include <TMC5160/TMC5160_registers.h>

//#include <TMC5160/TMC5160_SPI_STM32.h>
#include <MotorIoEvent.h>
#include <ResourceLock.h>
#include <System.h>
#include <SPI.h>

#define MOTOR_N 4

 

#define MOTOR_FUNCTION_NONE				0
#define MOTOR_FUNCTION_INIT				1
#define MOTOR_FUNCTION_HOMING			2
#define MOTOR_FUNCTION_TUNEPOWERSTAGE	100
#define MOTOR_FUNCTION_STEALTHCHOP2		101
#define MOTOR_FUNCTION_STEALGUARD2		102





#define DEFAULT_DRIVER_drvStrength 0
#define DEFAULT_DRIVER_bbmTime		8
#define DEFAULT_DRIVER_bbmClks		0
#define DEFAULT_DRIVER_senseResistor				220
#define DEFAULT_motorCurrent						1000
#define DEFAULT_motorCurrentReduction				0
#define DEFAULT_freewheeling						TMC5160_Reg::FREEWHEEL_NORMAL
#define DEFAULT_iholddelay							7	
#define DEFAULT_pwmOfsInitial						150
#define DEFAULT_pwmGradInitial						30
#define DEFAULT_stepperDirection					1
#define DEFAULT_motorSteps							200

#define DEFAULT_PWMTHRS								0.0
#define DEFAULT_COOLTHRS							0.0
#define DEFAULT_HIGHTHRS							0.0
#define DEFAULT_SWMODE								0
#define DEFAULT_RAMPMODE							POSITIONING_MODE
#define DEFAULT_MAXSPEED							200.0
#define DEFAULT_RAMPSPEEDS_START					0.0
#define DEFAULT_RAMPSPEEDS_STOP						0.1
#define DEFAULT_RAMPSPEEDS_HOLD						100.0
#define DEFAULT_ACCELERATIONS_AMAX					250.0
#define DEFAULT_ACCELERATIONS_DMAX					350.0
#define DEFAULT_ACCELERATIONS_A1					500.0
#define DEFAULT_ACCELERATIONS_D1					700.0
#define DEFAULT_HOMING_MODE							0
#define DEFAULT_HOMING_OFFSET						0.0
#define DEFAULT_ENCODER_RESOLUTION					0
#define DEFAULT_ENCODER_ALLOWEDDEVIATION			0
#define DEFAULT_ENCODER_SETUP						0
#define DEFAULT_ENCODER_INVERTED					0
#define DEFAULT_HOMING_MAXPOS						1000000
#define DEFAULT_HOMING_TIMEOUT						100000
#define DEFAULT_HOMING_SPEED2						10
#define DEFAULT_HOMING_accelerationsDmax			(DEFAULT_ACCELERATIONS_D1*3)


#define g_Motor1 g_Motor[0]
#define g_Motor2 g_Motor[1]
#define g_Motor3 g_Motor[2]
#define g_Motor4 g_Motor[3]
#define MOTOR1 0
#define MOTOR2 1
#define MOTOR3 2
#define MOTOR4 3


class HomingParameters {
public:
	uint8_t mode = 0;
	uint32_t timeOut = DEFAULT_HOMING_TIMEOUT;
	uint32_t maxPos = DEFAULT_HOMING_MAXPOS;
	float rampSpeed = DEFAULT_MAXSPEED;
	float rampSpeed_2 = DEFAULT_HOMING_SPEED2;
	double  homingOffset = 0;
	float rampSpeedStart = DEFAULT_RAMPSPEEDS_START;
	float rampSpeedStop = DEFAULT_RAMPSPEEDS_STOP;
	float rampSpeedHold = DEFAULT_RAMPSPEEDS_HOLD;
	float accelerationsAmax = DEFAULT_ACCELERATIONS_AMAX;
	float accelerationsDmax = DEFAULT_ACCELERATIONS_DMAX;
	float accelerationsA1 = DEFAULT_ACCELERATIONS_A1;
	float accelerationsD1 = DEFAULT_ACCELERATIONS_D1;
	void LoadfromEEprom(void *motor);
	

};





class MotorClass 
{
private:
	uint8_t _CS;
	SPISettings _spiSettings;
	SPIClass *_spi;

	void _beginTransaction();
	void _endTransaction();
	uint32_t _fclk;
public:
	uint32_t readRegister(uint8_t address);	// addresses are from TMC5160.h
	uint32_t readRegisterTest(uint8_t address);
	uint8_t  writeRegister(uint8_t address, uint32_t data);
	uint8_t  readStatus();
	uint8_t Init();
 protected:
	 int8_t  m_Nr=-1;				// IC driver nr 0..(MOTOR_N-1)
	
	 uint16_t m_InterruptOutPin=0;		// interrupt Output Pin
	
	 uint16_t  m_EnablePin =0;
	 int32_t m_MaxRampSpeed = 0;
	 int32_t m_AccelerationAmax = 0;
	 int32_t m_AccelerationA1 = 0;
	 int32_t m_AccelerationDmax = 0;
	 int32_t m_AccelerationD1 = 1;
	 int32_t m_RampSpeedsStart = 0;
	 int32_t m_RampSpeedsStop = 10;
	 int32_t m_RampSpeedsHold = 0;
	 int32_t m_ModeChangeSpeedsPwmThrs = 0;
	 int32_t m_ModeChangeSpeedsHighThrs = 0;
	 int32_t m_ModeChangeSpeedsCoolThrs = 0;
	 int16_t m_MotorSteps = 200;
	 int16_t m_EncResolution = 0;
	 uint16_t m_EncoderIndexConfiguration = 0;
	 uint8_t m_EncoderLatching : 1;
	 uint32_t m_COOLCONF_Register = 0;
	 
 public:
	 static constexpr uint8_t IC_VERSION = 0x30;
	 enum Command {
		  CurrentPosition, EncoderPosition, LatchedPosition, LatchedEncoderPosition, TargetPosition, CurrentSpeed,
		 MaxSpeed, RampSpeedsStart, RampSpeedsStop, RampSpeedsHold, Acceleration, AccelerationAMAX, AccelerationDMAX, AccelerationA1, AccelerationD1,
		 ModeChangeSpeeds1, ModeChangeSpeeds2, ModeChangeSpeeds3, MoveRelative
	 };
	 enum Motor
	 { NORMAL_MOTOR_DIRECTION = 0x00, INVERSE_MOTOR_DIRECTION = 0x1 };
	 enum RampMode { POSITIONING_MODE, VELOCITY_MODE, HOLD_MODE };


	 struct PowerStageParameters {
		 uint8_t drvStrength = 2; // MOSFET gate driver current (0 to 3)
		 uint8_t bbmTime = 0; // "Break Before Make" duration specified in ns (0 to 24)
		 uint8_t bbmClks = 4; // "Break Before Make" duration specified in clock cycles (0 to 15).
	 };

	 struct MotorParameters {
		 uint16_t globalScaler = 48; // global current scaling (32 to 256)
		 uint8_t irun = 16; // motor run current (0 to 31). For best performance don't set lower than 16
		 uint8_t ihold = 0; // standstill current (0 to 31). Set 70% of irun or lower.
		 TMC5160_Reg::PWMCONF_freewheel_Values freewheeling = TMC5160_Reg::FREEWHEEL_NORMAL; // Freewheeling / passive braking of ihold = 0
		 uint8_t pwmOfsInitial = 30; // initial stealthChop PWM amplitude offset (0-255)
		 uint8_t pwmGradInitial = 0; // initial stealthChop velocity dependent gradient for PWM amplitude
	 };

	 struct MotorSetup {
		 uint16_t senseResistor = DEFAULT_DRIVER_senseResistor; //Sense resistors value mOhms
		 uint16_t motorCurrent = DEFAULT_motorCurrent;	//Motor phase current mA 
		 uint16_t motorCurrentReduction = DEFAULT_motorCurrentReduction;	//Motor current standstill  current mA // 0 =FREEWHEEL NORMAL ; -1 = FREEWHEEL ENABLED; -2 = FREEWHEEL SHORT LS 
		 TMC5160_Reg::PWMCONF_freewheel_Values freewheeling = TMC5160_Reg::FREEWHEEL_NORMAL; // Freewheeling / passive 
		 uint8_t iholddelay = 7;
		 uint8_t pwmOfsInitial = 30; // initial stealthChop PWM amplitude offset (0-255)
		 uint8_t pwmGradInitial = 0; // initial stealthChop velocity dependent gradient for PWM amplitude
		 //uint32_t coolConf = 0;
	 };

	

	 

	

	 struct MotorSetupSave {
		 PowerStageParameters powerStageParameters;
		 MotorClass::MotorSetup motorSetup;
		 uint8_t stepperDirection =1;
	 };
	
	 ResourceLockClass m_Lock;
	 TMC5160_Reg::RAMP_STAT_Register m_RampStatus = { 0 };
	 uint8_t Init(
		 uint8_t  nr,				// IC driver nr 
		 uint16_t enablePin,		// driver outut Enable
		 uint16_t intOutPin,		// interrupt Output Pin
		 uint16_t chipSelectPin,	// pin to use for the SPI bus SS line
		 uint16_t sclk = PA5,
		 uint16_t miso = PA6,
		 uint16_t mosi = PA7,
		 uint32_t fclk =  DEFAULT_F_CLK,
		 const SPISettings &spiSettings = SPISettings(1000000, MSBFIRST, SPI_MODE0), // spi bus settings to use
		 SPIClass& spi = SPI); // spi class to use
	 


	 HomingParameters m_HomingParameters;
	 uint8_t m_LookUserTask=0;
	 uint8_t m_LookUserTaskSub=0;
	 int GetInterruptPin() { if (m_InterruptOutPin) return digitalRead(m_InterruptOutPin); else return -1; };
	 void MotorFunction();
	 MotorClass();

	 int32_t SteppToMStepp(double value);

	 double MSteppToStepp(int32_t value);


	 bool Begin(MotorSetupSave motorSetupSave);
	 bool Begin() { return Begin(m_MotorSetupSave); };
	
	 void Stop(); //* Stop the current motion according to the set ramp mode and motion parameters. The max speed and start speed are set to 0 but the target position stays unchanged.

	 
	 void Enable(uint8_t enable); //* 1 = Enable the driver ; 0=//* Disable the driver, all bridges off
	 uint8_t IsEnable();
	 void  EEpromInitDefault(uint8_t mode);
	 void SaveMotorParameter();
	 void  LoadMotorParameter();
	 void StartUpTestController(uint8_t nr);

	 MotorSetupSave m_MotorSetupSave;
	 MotorIoEventClass m_MotorIoEvent;
	 TaskHandle_t m_pxCreatedTask;
	 uint32_t MotorFunction_WaitEvent(uint32_t timeout = portMAX_DELAY);
	 void MotorFunction_TiggerStart(uint32_t sub);
	 void MotorFunction_TiggerStop();

	 MotorClass::MotorParameters GetMotorParameter(MotorSetup motorSetup);
	 MotorClass::MotorParameters SetMotorParameter(MotorSetup motorSetup);

	 
	 


	 void  SetFreewheelingMode(uint8_t mode = 1);// 0=Normal operation; 1= freewheeling; 2 = Coil shorted using LS drivers; 3 = Coil shorted using HS drivers
	 uint8_t GetFreewheelingMode();
	 TMC5160_Reg::RAMP_STAT_Register GetResetEvents();

	 static float GetMotorMaxRmsCurrent(uint32_t senseResistor);

	
	 int32_t GetCurrentSpeedInt();//* Return the current speed (microsteps / second)
	 double GetCurrentSpeed();//* Return the current speed (steps / second)

	 void SetTargetPositionInt(int32_t position);//* Set the target position in microsteps /!\ Set all other motion profile parameters before
	 void SetTargetPosition(double position);//* Set the target position in steps /!\ Set all other motion profile parameters before
	 int32_t GetTargetPositionInt(); 
	 double GetTargetPosition();

	 void SetCurrentPositionInt(int32_t position, bool updateEncoderPos = false);//
	 void SetCurrentPosition(double position, bool updateEncoderPos = false);//
	 int32_t GetCurrentPositionInt();
	 double GetCurrentPosition();

	 void Set0Position(double position, bool updateEncoderPos = false);


	 double GetEncoderPosition();
	 int32_t GetEncoderPositionInt();
	 double GetLatchedPosition();
	 int32_t GetLatchedPositionInt();
	 double GetLatchedEncoderPosition();
	 int32_t GetLatchedEncoderPositionInt();
	 
	 void SetAcceleration_AMAX_Int(uint32_t maxAccel);
	 uint32_t GetAcceleration_AMAX_Int();
	 void SetAcceleration_DMAX_Int(uint32_t maxDecel);
	 uint32_t GetAcceleration_DMAX_Int();
	 void SetAcceleration_A1_Int(uint32_t startAccel);
	 uint32_t GetAcceleration_A1_Int();
	 void SetAcceleration_D1_Int(uint32_t finalDecel);
	 uint32_t GetAcceleration_D1_Int();
	 void SetAcceleration_AMAX(double maxAccel);
	 double GetAcceleration_AMAX();
	 void SetAcceleration_DMAX(double maxDecel);
	 double GetAcceleration_DMAX();
	 void SetAcceleration_A1(double startAccel);
	 double GetAcceleration_A1();
	 void SetAcceleration_D1(double finalDecel);
	 double GetAcceleration_D1();
	 void SetAcceleration(double value);
	 void SetAccelerationInt(uint32_t value);

	 void SetAccelerations(double maxAccel, double maxDecel, double startAccel, double finalDecel);
	 void SetAccelerationsInt(uint32_t maxAccel, uint32_t maxDecel, uint32_t startAccel, uint32_t finalDecel);

	 void SetRampMode(MotorClass::RampMode mode);
	 uint32_t  GetRampMode();

	 void SetModeChangeSpeedsInt(uint32_t pwmThrs, uint32_t coolThrs, uint32_t highThrs);

	 void SetMaxSpeed(double speed);
	 void SetMaxSpeedInt(int speed);
	 double GetMaxSpeed();
	 int GetMaxSpeedInt( );
	 void SetRampSpeedStartInt(uint32_t startSpeed);
	 void SetRampSpeedStopInt(uint32_t stopSpeed);
	 void SetRampSpeedHoldInt(uint32_t holdSpeed);
	 
	 
	 void SetRampSpeedStart(double startSpeed);
	 void SetRampSpeedStop(double stopSpeed);
	 void SetRampSpeedHold(double holdSpeed);
	 void SetRampSpeedsInt(uint32_t startSpeed, uint32_t stopSpeed, uint32_t transitionSpeed);
	 void SetRampSpeeds(double startSpeed, double stopSpeed, double transitionSpeed);
	 double GetRampSpeedStart();
	 int GetRampSpeedStartInt();
	 double GetRampSpeedStop();
	 int GetRampSpeedStopInt();
	 double GetRampSpeedHold();
	 int GetRampSpeedHoldInt();
	 void SetModeChangeSpeeds_TpwmThrs_Int(uint32_t pwmThrs);
	 uint32_t GetModeChangeSpeeds_TpwmThrs_Int();
	 
	 void SetModeChangeSpeeds_CoolThrs_Int(uint32_t coolThrs);
	 uint32_t GetModeChangeSpeeds_CoolThrs_Int();
	 void SetModeChangeSpeeds_HighThrs_Int( uint32_t highThrs);
	 uint32_t GetModeChangeSpeeds_HighThrs_Int();
	 void SetModeChangeSpeeds_TpwmThrs(double pwmThrs);
	 double GetModeChangeSpeeds_TpwmThrs();
	 void SetModeChangeSpeeds_CoolThrs(double coolThrs);
	 double GetModeChangeSpeeds_CoolThrs();
	 void SetModeChangeSpeeds_HighThrs(double highThrs);
	 double GetModeChangeSpeeds_HighThrs();
	 void SetModeChangeSpeeds(double pwmThrs, double coolThrs, double highThrs);

	 void SetMoveRelativeInt(int32_t pos);
	 void SetMoveRelative(double pos);
	 void EmergencyStop(uint8_t reset=false);

	 uint32_t GetSW_ModeInt(); //  Get Switch mode register configuration
	 void SetSW_ModeInt(uint32_t); //  Get Switch mode register configuration 
	 TMC5160_Reg::SW_MODE_Register GetSW_Mode(); //  Get Switch mode register configuration
	 void SetSW_Mode(TMC5160_Reg::SW_MODE_Register ); //  Get Switch mode register configuration 

	 uint32_t GetDrvStatusInt(); //  Get Drver status
	 TMC5160_Reg::DRV_STATUS_Register GetDrvStatus();

	 uint32_t GetRampStatusInt(); // Get RAMP STATUS
	 TMC5160_Reg::RAMP_STAT_Register GetRampStatus(); // Get RAMP STATUS
	 void ResetRampStatus(uint32_t value= 0xffff); // Reset RAMP STATUS


	 TMC5160_Reg::COOLCONF_Register GetCOOLCONF();
	 uint32_t GetCOOLCONFInt();
	 void SetCOOLCONF(TMC5160_Reg::COOLCONF_Register value);
	 void SetCOOLCONFInt(uint32_t value);

	 uint32_t GetGstatInt();
	 TMC5160_Reg::GSTAT_Register GetGstat();
	 void ResetGstatInt(uint32_t gStat);
	 void  ResetGstat(TMC5160_Reg::GSTAT_Register gStat);
	 //uint32_t GetGStat();	 
	 //void SetGStat(uint32_t value);



	 
	

		 /* Set the encoder constant to match the motor and encoder resolutions.
		  * This function will determine if the binary or decimal mode should be used
		  * and return false if no exact match could be found (for example for an encoder
		  * with a resolution of 360 and a motor with 200 steps per turn). In this case
		  * the best approximation in decimal mode will be used.
		  *
		  * Params :
		  * 		motorSteps : the number of steps per turn for the motor
		  * 		encResolution : the actual encoder resolution (pulses per turn)
		  * 					is negativ is inverted 
		  *
		  * Return :
		  * 		true if an exact match was found, false otherwise
		  */
		 bool SetEncoderResolution(int motorSteps, int encResolution);

		 int GetEncoderResolution() {
			 return m_EncResolution;
		 };

	 /* Configure the encoder N event context.
	  * Params :
	  * 		sensitivity : set to one of ENCODER_N_NO_EDGE, ENCODER_N_RISING_EDGE, ENCODER_N_FALLING_EDGE, ENCODER_N_BOTH_EDGES
	  * 		nActiveHigh : choose N signal polarity (true for active high)
	  * 		ignorePol : if true, ignore A and B polarities to validate a N event
	  * 		aActiveHigh : choose A signal polarity (true for active high) to validate a N event
	  * 		bActiveHigh : choose B signal polarity (true for active high) to validate a N event
	  */
	 void SetEncoderIndexConfiguration(TMC5160_Reg::ENCMODE_sensitivity_Values sensitivity, bool nActiveHigh = true, bool ignorePol = true, bool aActiveHigh = false, bool bActiveHigh = false);
	 uint32_t GetEncoderIndexConfiguration() { return m_EncoderIndexConfiguration; };
	 /* Enable/disable encoder and position latching on each encoder N event (on each revolution)
	  * The difference between the 2 positions can then be compared regularly to check
	  * for an external step loss.
	  */
	 void SetEncoderLatching(bool enabled);
	 bool GetEncoderLatching() { return m_EncoderLatching; };

	 /* Set maximum number of steps between internal position and encoder position
	  * before triggering the deviation flag.
	  * Set to 0 to disable. */


	  /* Check if a deviation between internal pos and encoder has been detected */
	 bool IsEncoderDeviationDetected();

	 /* Clear encoder deviation flag (deviation condition must be handled before) */
	 void ClearEncoderDeviationFlag();

	 void SetMotorSteps(uint32_t nr) { m_MotorSteps = nr; };
	 uint32_t GetMotorSteps( ) { return m_MotorSteps; };


	 void SetEncoderAllowedDeviation(int steps);




	 uint32_t GetStartup_drvStrength();
	 void  SetStartup_drvStrength(uint32_t value);

	 uint32_t GetStartup_bbmTime();
	 void  SetStartup_bbmTime(uint32_t value);

	 uint32_t GetStartup_bbmClks();
	 void  SetStartup_bbmClks(uint32_t value);

	 uint32_t GetStartup_SenseResistor();
	 void  SetStartup_SenseResistor(uint32_t value);

	 uint32_t GetStartup_MotorCurrent();
	 void  SetStartup_MotorCurrent(uint32_t value);

	 uint32_t GetStartup_MotorCurrentReduction();
	 void  SetStartup_MotorCurrentReduction(uint32_t value);

	 uint32_t GetStartup_Freewheeling();
	 void  SetStartup_Freewheeling(uint32_t value);
	
	 uint32_t GetStartup_Iholddelay();
	 void  SetStartup_Iholddelay(uint32_t value);

	 uint32_t GetStartup_PwmOfsInitial();
	 void  SetStartup_PwmOfsInitial(uint32_t value);

	 uint32_t GetStartup_PwmGradInitial();
	 void  SetStartup_PwmGradInitial(uint32_t value);

	 uint32_t GetStartup_StepperDirection();
	 void  SetStartup_StepperDirection(uint32_t value);
	 
	 uint32_t GetStartup_MotorSteps();
	 void  SetStartup_MotorSteps(uint32_t value);

	 uint32_t GetStartup_PWMThrsInt();
	 double GetStartup_PWMThrs();
	 void SetStartup_PWMThrsInt(uint32_t value);
	 void  SetStartup_PWMThrs(double value);

	 uint32_t GetStartup_COOLThrsInt();
	 double GetStartup_COOLThrs();
	 void  SetStartup_COOLThrsInt(uint32_t value);
	 void  SetStartup_COOLThrs(double value);

	 double GetStartup_HighThrs();
	 uint32_t GetStartup_HighThrsInt();
	 void  SetStartup_HighThrsInt(uint32_t value);
	 void  SetStartup_HighThrs(double value);

	 uint32_t GetStartup_SWMode();
	 void  SetStartup_SWMode(uint32_t value);

	 uint32_t GetStartup_RampMode();
	 void  SetStartup_RampMode(uint32_t value);

	 float GetStartup_RampMaxSpeed();
	 void  SetStartup_RampMaxSpeed(float value);
	 uint32_t GetStartup_RampMaxSpeedInt();
	 void  SetStartup_RampMaxSpeedInt(uint32_t value);
	 
	 uint32_t GetStartup_RampSpeedsStartInt();
	 void  SetStartup_RampSpeedsStartInt(uint32_t value);
	 float GetStartup_RampSpeedsStart();
	 void  SetStartup_RampSpeedsStart(float value);

	 uint32_t GetStartup_RampSpeedsHoldInt();
	 void  SetStartup_RampSpeedsHoldInt(uint32_t value);
	 float GetStartup_RampSpeedsHold();
	 void  SetStartup_RampSpeedsHold(float value);

	 uint32_t GetStartup_RampSpeedsStopInt();
	 void  SetStartup_RampSpeedsStopInt(uint32_t value);
	 float GetStartup_RampSpeedsStop();
	 void  SetStartup_RampSpeedsStop(float value);

	 uint32_t GetStartup_AccelerationsAMaxInt();
	 void  SetStartup_AccelerationsAMaxInt(uint32_t value);
	 float GetStartup_AccelerationsAMax();
	 void  SetStartup_AccelerationsAMax(float value);

	 uint32_t GetStartup_AccelerationsDMaxInt();
	 void  SetStartup_AccelerationsDMaxInt(uint32_t value);
	 float GetStartup_AccelerationsDMax();
	 void  SetStartup_AccelerationsDMax(float value);

	 uint32_t GetStartup_AccelerationsA1Int();
	 void  SetStartup_AccelerationsA1Int(uint32_t value);
	 float GetStartup_AccelerationsA1();
	 void  SetStartup_AccelerationsA1(float value);

	 uint32_t GetStartup_AccelerationsD1Int();
	 void  SetStartup_AccelerationsD1Int(uint32_t value);
	 float GetStartup_AccelerationsD1();
	 void  SetStartup_AccelerationsD1(float value);
	 
	 uint32_t GetStartup_HomingMode();
	 void  SetStartup_HomingMode(uint32_t value);

	 uint32_t GetStartup_HomingOffsetInt();
	 void  SetStartup_HomingOffsetInt(uint32_t value);
	 double GetStartup_HomingOffset();
	 void  SetStartup_HomingOffset(double value);

	 

	 uint32_t GetStartup_EncoderResolution();
	 void  SetStartup_EncoderResolution(uint32_t value);

	 uint32_t GetStartup_EncoderAlloweddeviation();
	 void  SetStartup_EncoderAlloweddeviation(uint32_t value);

	 uint32_t GetStartup_EncoderSetup();
	 void  SetStartup_EncoderSetup(uint32_t value);

	 uint32_t GetStartup_EncoderInverted();
	 void  SetStartup_EncoderInverted(uint32_t value);
	 
	 uint32_t GetStartup_HomingMaxPos();
	 void SetStartup_HomingMaxPos(uint32_t value);
	 
	 uint32_t GetStartup_HomingTimeout();
	 void  SetStartup_HomingTimeout(uint32_t value);

	 uint32_t GetStartup_HomingSpeed2Int();
	 void  SetStartup_HomingSpeed2Int(uint32_t value);
	 float GetStartup_HomingSpeed2();
	 void  SetStartup_HomingSpeed2(float value);

	 uint32_t GetStartup_HomingDmaxInt();
	 void  SetStartup_HomingDmaxInt(uint32_t value);
	 float GetStartup_HomingDmax();
	 void  SetStartup_HomingDmax(float value);


	 uint32_t GetStartup_COOLCONF();
	 void SetStartup_COOLCONF(uint32_t value);
	

	 void  SetMotorCurrent(uint32_t current_mA);
	 uint32_t  GetMotorCurrent() { return m_MotorSetupSave.motorSetup.motorCurrent; };
	 void  SetMotorCurrentHold(uint32_t current_mA);
	 uint32_t  GetMotorCurrentHold() { return m_MotorSetupSave.motorSetup.motorCurrentReduction; };
	 void  SetMotorSenseResistor(uint32_t senseResistor);
	 uint32_t  GetMotorSenseResistor() { return m_MotorSetupSave.motorSetup.senseResistor; };
	 void  SetMotorIholddelay(uint32_t iholddelay);
	 uint32_t  GetMotorIholddelay() { return m_MotorSetupSave.motorSetup.iholddelay; };

	 uint8_t GetMotorNr() { return m_Nr; };
	 void SetMicroStepRes(uint16_t enable);
	 uint16_t GetMicroStepRes();
	 
	 eTaskState m_MotorFunctionStatus = eTaskState::eInvalid;
	 long ThrsSpeedToTstep(double thrsSpeed) { return thrsSpeed != 0.0 ? (long)constrain((double)_fclk / (thrsSpeed * 256.0), 0, 1048575) : 0; }
	 double ThrsSpeedTstepToSpeed(long thrs) { return (double)thrs*_fclk / 256.0; };

	 // Following �14.1 Real world unit conversions
	 // v[Hz] = v[5160A] * ( f CLK [Hz]/2 / 2^23 )
	 double SpeedToHz(long speedInternal) { return ((double)speedInternal * (double)_fclk / (double)(1 << 24) / (double)_uStepCount); }
	 long SpeedFromHz(double speedHz) { return (long)(speedHz / ((double)_fclk / (double)(1 << 24)) * (double)_uStepCount); }

	 // Following �14.1 Real world unit conversions
	 // a[Hz/s] = a[5160A] * f CLK [Hz]^2 / (512*256) / 2^24
	 long AccelFromHz(double accelHz) { return (long)(accelHz / ((double)_fclk * (double)_fclk / (512.0*256.0) / (double)(1 << 24)) * (double)_uStepCount); }
	 double AccelToHz(long accel) { return (double)(accel * ((double)_fclk * (double)_fclk / (512.0*256.0) / (double)(1 << 24)) / (double)_uStepCount); }
	
	 uint8_t GetLimitSwitshLeft() { return GetRampStatus().status_stop_l ? 1 : 0; };
	 uint8_t GetLimitSwitshRigth() { return GetRampStatus().status_stop_r ? 1 : 0; };
	 

protected:
		static constexpr uint8_t WRITE_ACCESS = 0x80;	//Register write access for spi / uart communication
		static constexpr uint32_t DEFAULT_F_CLK = 12000000; // Typical internal clock frequency in Hz.

		bool _lastRegisterReadSuccess = false;
		TMC5160_Reg::CHOPCONF_Register _chopConf = { 0 }; //CHOPCONF register (saved here to be restored when disabling / enabling driver)
		uint16_t _uStepCount = 256; // Number of microsteps per step
		// See �12 Velocity based mode control
		
		RampMode _currentRampMode;
		void  SetFreewheelingModeEx(MotorSetup mode);
};

extern MotorClass g_Motor[MOTOR_N];

#endif
