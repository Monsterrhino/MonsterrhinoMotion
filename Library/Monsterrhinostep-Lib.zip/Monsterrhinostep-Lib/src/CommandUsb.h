// CommandUsb.h

#ifndef _COMMANDUSB_h
#define _COMMANDUSB_h


#define VIEW_COMMAND
#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

namespace ComandUSB {

	enum DecMode {
		None = 0,
		Get = 1,
		Set = 4,
		GetHex = 2,
		SetHex = 3,
		GetInt = 5,
		SetInt = 6,

	};
};

uint8_t IsGet_HEX(char *str);
bool CommandUSB(char *str);
bool CommandUSB_Motor(char *str);
ComandUSB::DecMode GetDecMode(char *str);
void CommandUSB_PrintTitle(const char *title, ComandUSB::DecMode decMode, uint8_t *nr=NULL);
bool Command_UserFunction(char *str);
bool CommandUSB_Input(char *str);
bool CommandUSB_System(char *str);
bool CommandUSB_Motor_Homing(uint8_t nr, char *str);
void PrintMotorIsLocked(uint8_t nr);
void PrintPWMIsLocked(uint8_t nr);
void Print_HexUint32(uint32_t value);
#endif

