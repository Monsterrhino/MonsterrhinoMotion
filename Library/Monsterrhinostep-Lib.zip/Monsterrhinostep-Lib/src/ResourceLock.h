// ResourceLock.h

#ifndef _RESOURCELOCK_h
#define _RESOURCELOCK_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif

void InitLock();

#define OUTPUT_PWM_N 3


#define LOCK_PWM1_NR	4
#define LOCK_PWM2_NR	5
#define LOCK_PWM3_NR	6
#define LOCK_MOTOR1 (0x01<<0)
#define LOCK_MOTOR2 (0x01<<1)
#define LOCK_MOTOR3 (0x01<<2)
#define LOCK_MOTOR4 (0x01<<3)
#define LOCK_PWM1	(0x01<<LOCK_PWM1_NR)
#define LOCK_PWM2	(0x01<<LOCK_PWM2_NR)
#define LOCK_PWM3	(0x01<<LOCK_PWM3_NR)



#define INITOK_MOTOR1 (0x01<<7)
#define INITOK_MOTOR2 (0x01<<8)
#define INITOK_MOTOR3 (0x01<<9)
#define INITOK_MOTOR4 (0x01<<10)
#define INITERROR_MOTOR1 (0x01<<11)
#define INITERROR_MOTOR2 (0x01<<12)
#define INITERROR_MOTOR3 (0x01<<13)
#define INITERROR_MOTOR4 (0x01<<14)


//#define MOTOR1_LOCK (1<<0)
//#define MOTOR2_LOCK (1<<1)
//#define MOTOR3_LOCK (1<<2)
//#define MOTOR4_LOCK (1<<3)


#define MOTOR1_FAILED (1<<7)
#define MOTOR2_FAILED (1<<8)
#define MOTOR3_FAILED (1<<9)
#define MOTOR4_FAILED (1<<10)
#define MOTOR1_HOMING_OK (1<<11)
#define MOTOR2_HOMING_OK (1<<12)
#define MOTOR3_HOMING_OK (1<<13)
#define MOTOR4_HOMING_OK (1<<14)
#define MOTOR1_INIT_OK (1<<15)
#define MOTOR2_INIT_OK (1<<16)
#define MOTOR3_INIT_OK (1<<17)
#define MOTOR4_INIT_OK (1<<18)


#define LOCK_MASK_MOTOR (LOCK_MOTOR1|LOCK_MOTOR2|LOCK_MOTOR3|LOCK_MOTOR4)
#define LOCK_MASK (LOCK_MOTOR1|LOCK_MOTOR2|LOCK_MOTOR3|LOCK_MOTOR4|LOCK_PWM1|LOCK_PWM2|LOCK_PWM3)

class ResourceLockClass
{
protected:
	uint8_t m_Nr = 0;
	uint8_t m_Sub = 0;
	uint32_t m_LockMask = 0;
	void Lock_print_title(uint8_t sub);
	void Lock_print_title(uint8_t nr, uint8_t sub);
	EventGroupHandle_t *m_pEventGroup=NULL;
public:
	ResourceLockClass();
	void Init(uint8_t nr, EventGroupHandle_t *pEventGroup);
	void SetLockNr(uint8_t mask,  uint8_t sub);
	void SetUnLockNr(uint8_t mask);
	uint8_t GetLockNr(uint8_t motorNr, uint8_t &mask, uint8_t &set);
	void Lock_print_used_resource(char* title, uint32_t lock);
	void Lock_print_used_in(char* title, uint32_t look, uint8_t sub);
	void Lock_print_used_in(uint8_t nrMotor);
	void Lock_print_wait_init(char* title, uint32_t look, uint8_t sub);
	static int8_t IsLock(uint32_t resurce);
	int8_t IsLock();
	int8_t Lock_Wait(uint32_t resurce,  uint8_t sub, uint32_t timeout = portMAX_DELAY);
	int8_t Lock(uint32_t resurce, uint8_t sub, uint32_t timeout = portMAX_DELAY);
	int8_t MotorInitOk(uint32_t resurce, uint8_t sub, uint32_t timeout);
	int8_t MotorHomingOk(uint32_t resurce, uint8_t sub, uint32_t timeout = portMAX_DELAY);
	void Unlock();
	static void Unlock(uint8_t nr);
	void Print_exit();
private:

};



extern EventGroupHandle_t m_LockRes;


#endif

