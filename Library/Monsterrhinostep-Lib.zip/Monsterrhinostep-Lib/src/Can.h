// Can.h







#ifndef _CAN_h
#define _CAN_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif
#include <STM32FreeRTOS.h>

//#define STM32F072Vx 

#define CAN_RX_BUFFER_SIZE 32
#define CAN_TX_BUFFER_SIZE 32

#define CAN_ERROR_RXBUFFER_OVERLOW 1


class CanDataClass
{
public:
	uint32_t Id;    /*!< Specifies the standard/extended identifier.
						  This parameter must be a number between Min_Data = 0 and Max_Data = 0x7FF. */
	uint8_t IDE:1;      /*!< Specifies the type of identifier for the message that will be transmitted.
							This parameter can be a value of @ref CAN_identifier_type */
	uint8_t RTR:1;      /*!< Specifies the type of frame for the message that will be transmitted.
							This parameter can be a value of @ref CAN_remote_transmission_request */
	uint8_t DLC:4;      /*!< Specifies the length of the frame that will be transmitted.
							This parameter must be a number between Min_Data = 0 and Max_Data = 8. */
	uint8_t DATA[8];
	CanDataClass();
	CanDataClass(CAN_RxHeaderTypeDef header,uint8_t *data);
	CanDataClass(CAN_TxHeaderTypeDef header, uint8_t *data);
	CAN_TxHeaderTypeDef GetHeader();
};

class CanClass
{
 protected:
	 CanDataClass rx_buffer[CAN_RX_BUFFER_SIZE];
	 CanDataClass tx_buffer[CAN_TX_BUFFER_SIZE];
	 uint16_t rx_head = 0;
	 uint16_t rx_tail = 0;
	 uint16_t tx_head = 0;
	 uint16_t tx_tail = 0;
	 uint8_t error;
	 bool _written = 0;
	 bool timeoutError = 0;
 public:
	 //void * m_CanTaskFunc;
	 
	 uint32_t              TxMailbox;
	 CAN_HandleTypeDef hcan;
	 //CAN_RxHeaderTypeDef RxMessage;
	 void AddData(CAN_RxHeaderTypeDef rxHeader, uint8_t *rxData);
	 uint8_t  Read(CanDataClass &data);
	 uint8_t Peek(CanDataClass &data);
	 //uint8_t Peek(CAN_RxHeaderTypeDef &rxHeader, uint8_t &rxData);
	 int Available(void);
	 HAL_StatusTypeDef Init(uint8_t add = 2, uint8_t speed = 1);
	 HAL_StatusTypeDef DeInit();
	 HAL_StatusTypeDef Start();
	 HAL_StatusTypeDef Stop();
	 
	 int Write(CAN_TxHeaderTypeDef txHeader, uint8_t *txData);
	 int WriteStd(uint16_t id, uint8_t len, uint8_t *txData, uint8_t RTR= CAN_RTR_DATA);
	 int WriteStd_uint8(uint16_t id, uint8_t data, uint8_t RTR = CAN_RTR_DATA);
	 int WriteStd_uint16(uint16_t id, uint16_t data, uint8_t RTR = CAN_RTR_DATA);
	 int WriteStd_uint32(uint16_t id, uint32_t data, uint8_t RTR = CAN_RTR_DATA);
	 int WriteExt(uint32_t id, uint8_t len, uint8_t *txData, uint8_t RTR = CAN_RTR_DATA);
	 int WriteExt_uint8(uint32_t id, uint8_t data, uint8_t RTR = CAN_RTR_DATA);
	 int WriteExt_uint16(uint32_t id, uint16_t data, uint8_t RTR = CAN_RTR_DATA);
	 int WriteExt_uint32(uint32_t id, uint32_t data, uint8_t RTR = CAN_RTR_DATA);
	 uint8_t _tx_complete_irq(CAN_TxHeaderTypeDef &txHeader, uint8_t *txData);
	 int AvailableForWrite(void);
	 void Flush();
	 void SetAdd(uint8_t add);
	 
};

extern CanClass g_Can;

#endif

